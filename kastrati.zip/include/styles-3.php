<!--- Header transparent --->
<style>
#logo{
    padding: 0 30px 0 0!important
}



@media only screen and (max-width: 600px) {
#bs-example-navbar-collapse-1 {
    background-color: <?php  echo  get_theme_mod( 'gr_submenu_setting', '#fff' );?>;
     
}
}






</style>