<!--- Header full --->
<style> 
header{
    background:<?php  echo  get_theme_mod( 'gr_header_background_settings', '#000' );?>;
}
</style>