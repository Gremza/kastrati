<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_floating_menu_wrap extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'visibility'		=>		'maw_floatmenu_right',
			'scrollspeed'		=>		'500',
			'topspace'			=>		'500',
			'showonmobile'		=>		'show',
		), $atts ) );
		$some_id = rand(5, 500);
		$content = wpb_js_remove_wpautop($content, true);
		wp_enqueue_style( 'floating-menu-css', plugins_url( '../css/floatingmenu.css' , __FILE__ ));
		wp_enqueue_script( 'floatingmenu-js', plugins_url( '../js/floatingmenu.js' , __FILE__ ));
		ob_start(); ?>
		<div class="maw_floatmenu_main_wrapper maw_floatmenu_main_wrapper_<?php echo $some_id; ?> <?php echo $visibility ?>" data-scrollspeed="<?php echo $scrollspeed ?>" data-topspace="<?php echo $topspace; ?>">
		    <div class="maw_floatmenu_style_1">
		    	<ul class="maw_floatmenu_nav">
					<?php echo $content; ?>
				</ul>
		    </div>
		</div>
		<?php if ($showonmobile == "hide") { ?>
			<style>
				@media only screen and (max-width: 480px) {
					.maw_floatmenu_main_wrapper_<?php echo $some_id; ?> {
						display: none;
					}
				}
			</style>
		<?php } ?>

		<?php return ob_get_clean();
	}
}


vc_map( array(
	"base" 			=> "floating_menu_wrap",
	"name" 			=> __( 'Floating Menu', 'megaaddons' ),
	"as_parent" 	=> array('only' => 'floating_menu_son'),
	"content_element" => true,
	"js_view" 		=> 'VcColumnView',
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('One page navigator sticky menu', 'megaaddons'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/floatmenu.png',
	'params' => array(
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Visibility On', 'megaaddons' ),
			"param_name" 	=> 	"visibility",
			"description" 	=> 	__( 'choose style <a href="https://addons.topdigitaltrends.net/wp-floating-menu/">See demo</a>', 'megaaddons' ),
			"group" 		=> 'General',
			"value"			=> array(
				"Right Side"		=>	"maw_floatmenu_right",
				"Left Side"			=>	"maw_floatmenu_left",
			)
		),

		array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Scroll Speed', 'megaaddons' ),
			"param_name" 	=> 	"scrollspeed",
			"suffix" 		=> 	"ms",
			"value" 		=> 	"500",
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Top Space', 'megaaddons' ),
			"param_name" 	=> 	"topspace",
			"suffix" 		=> 	"px",
			"description" 	=> 	__( 'if you want extra space (header height), then include this value in px', 'megaaddons' ),
			"group" 		=> 	'General',
        ),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide on Mobile', 'megaaddons' ),
			"param_name" 	=> 	"showonmobile",
			"group" 		=> 'General',
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),
	)
) 
);
