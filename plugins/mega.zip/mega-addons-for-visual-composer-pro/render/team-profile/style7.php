<?php $some_id = rand(5, 500); ?>
<div class="mega_team_case_7 mega-team-case-7<?php echo $some_id; ?> <?php echo $classname; ?>" style="width: <?php echo $pro_size; ?>px;">
    <?php if (isset($url) && $url != '') { ?>
        <a class="mega-team-wrap" href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>">
    <?php } ?>
    <?php if (isset($url) && $url == NULL) { ?>
        <a class="mega-team-wrap">
    <?php } ?>
    	<div class="mega-team-img-sec">
    		<span style="font-size:0"></span>
        	<div>
                <img src="<?php echo $image_url; ?>" alt="<?php echo $image_alt; ?>" class="mega-team-img">
        	</div>
    	</div>
    	<div class="mega-team-content" style="color: <?php echo $memberproclr; ?>;">
    		<strong style="font-size: <?php echo $member_txt_size; ?>px;"><?php echo $memb_name; ?></strong>
    		<span style="font-size: <?php echo $pro_txt_size; ?>px;"><?php echo $memb_prof; ?></span>
    	</div>
    </a>
</div>

<style>
    .mega-team-case-7<?php echo $some_id; ?> .mega-team-wrap::before {
        border: 2px solid <?php echo $member_clr; ?> !important;
    }
</style>