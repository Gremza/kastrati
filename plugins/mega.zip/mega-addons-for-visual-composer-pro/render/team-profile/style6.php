<div class="mega_team_case_6 <?php echo $classname; ?>" style="max-width: <?php echo $pro_size; ?>px; width: 100%;">
	<div class="mega-team-wrap">
		<?php if (isset($url) && $url != '') { ?>
            <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>">
        <?php } ?>
        <?php if (isset($url) && $url == NULL) { ?>
            <a>
        <?php } ?>
			<img src="<?php echo $image_url; ?>" alt="<?php echo $image_alt; ?>" class="top-img wp-post-image">
			<img src="<?php echo $image_url2; ?>" alt="<?php echo $image_alt; ?>" class="hover-img">
		</a>
		<div class="mega-team-content">
			<h5 class="entry-title" style="font-size: <?php echo $member_txt_size; ?>px;">
				<?php if (isset($url) && $url != '') { ?>
                    <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>">
                <?php } ?>
                <?php if (isset($url) && $url == NULL) { ?>
                    <a>
                <?php } ?>
                	<?php echo $memb_name; ?>
                </a>
			</h5>
			<h6 class="job-title" style="color: <?php echo $memberproclr; ?>; font-size: <?php echo $pro_txt_size; ?>px;">
				<?php echo $memb_prof; ?>
			</h6>
			<div class="summary" style="color: <?php echo $about_clr; ?>; font-size: <?php echo $about_txt_size; ?>px;">
				<p><?php echo $memb_about; ?></p>
			</div>	
		</div>
		<div class="member-social">
			<?php if (!empty($social_icon)) { ?>
                <a href="<?php echo $social_url; ?>" style="color: <?php echo $social_clr; ?>;" target="_blank">
                    <i class="<?php echo $social_icon; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                </a>
            <?php } ?>
            <?php if (!empty($social_icon2)) { ?>
                <a href="<?php echo $social_url2; ?>" style="color: <?php echo $social_clr2; ?>;" target="_blank">
                    <i class="<?php echo $social_icon2; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                </a>
            <?php } ?>
            <?php if (!empty($social_icon3)) { ?>
                <a href="<?php echo $social_url3; ?>" style="color: <?php echo $social_clr3; ?>;" target="_blank">
                    <i class="<?php echo $social_icon3; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                </a>
            <?php } ?>
            <?php if (!empty($social_icon4)) { ?>
                <a href="<?php echo $social_url4; ?>" style="color: <?php echo $social_clr4; ?>;" target="_blank">
                    <i class="<?php echo $social_icon4; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                </a>
            <?php } ?>
            <?php if (!empty($social_icon5)) { ?>
                <a href="<?php echo $social_url5; ?>" style="color: <?php echo $social_clr5; ?>;" target="_blank">
                    <i class="<?php echo $social_icon5; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                </a>
            <?php } ?>
		</div>
	</div>
</div>