<?php $some_id = rand(5, 500); ?>
<div class="mega_team_case_5 mega-team-case-5<?php echo $some_id; ?> <?php echo $classname; ?>" style="max-width: <?php echo $pro_size; ?>px;">
    <div class="mega-team-wrap">
        <?php if (isset($url) && $url != '') { ?>
            <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>"><img src="<?php echo $image_url; ?>" alt="<?php echo $image_alt; ?>"></a>
        <?php } ?>
        <?php if (isset($url) && $url == NULL) { ?>
            <a><img src="<?php echo $image_url; ?>" alt="<?php echo $image_alt; ?>"></a>
        <?php } ?>
        <div class="mega-team-content">
            <h3 class="teacher-name" style="font-size: <?php echo $member_txt_size; ?>px;">
                <?php if (isset($url) && $url != '') { ?>
                    <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>">
                <?php } ?>
                <?php if (isset($url) && $url == NULL) { ?>
                    <a>
                <?php } ?>
                    <?php echo $memb_name; ?>
                </a>
                <span style="color: <?php echo $member_clr; ?>; font-size: <?php echo $pro_txt_size; ?>px;">
                    <?php echo $memb_prof; ?>
                </span>
            </h3>
            <p class="text" style="color: <?php echo $about_clr; ?>; font-size: <?php echo $about_txt_size; ?>px;">
                <?php echo $memb_about; ?>
            </p>
            <div class="teacher-bottom">
                <ul class="list-inline social-group">
                    <?php if (!empty($social_icon)) { ?>
                        <li><a href="<?php echo $social_url; ?>" style="color: <?php echo $social_clr; ?>;" target="_blank">
                            <i class="<?php echo $social_icon; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                        </a></li>
                    <?php } ?>
                    <?php if (!empty($social_icon2)) { ?>
                        <li><a href="<?php echo $social_url2; ?>" style="color: <?php echo $social_clr2; ?>;" target="_blank">
                            <i class="<?php echo $social_icon2; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                        </a></li>
                    <?php } ?>
                    <?php if (!empty($social_icon3)) { ?>
                        <li><a href="<?php echo $social_url3; ?>" style="color: <?php echo $social_clr3; ?>;" target="_blank">
                            <i class="<?php echo $social_icon3; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                        </a></li>
                    <?php } ?>
                    <?php if (!empty($social_icon4)) { ?>
                        <li><a href="<?php echo $social_url4; ?>" style="color: <?php echo $social_clr4; ?>;" target="_blank">
                            <i class="<?php echo $social_icon4; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                        </a></li>
                    <?php } ?>
                    <?php if (!empty($social_icon5)) { ?>
                        <li><a href="<?php echo $social_url5; ?>" style="color: <?php echo $social_clr5; ?>;" target="_blank">
                            <i class="<?php echo $social_icon5; ?>" style="font-size: <?php echo $social_size; ?>px;"></i>
                        </a></li>
                    <?php } ?>
                </ul>
                <?php if (isset($url) && $url != '') { ?>
                    <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>">
                <?php } ?>
                <?php if (isset($url) && $url == NULL) { ?>
                    <a>
                <?php } ?>
                        <i class="fa  fa-long-arrow-right" style="float: right; font-size: 23px; line-height: 2; color: <?php echo $member_clr; ?>;" aria-hidden="true"></i>
                    </a>
            </div>
        </div >
    </div>
</div>

<style>
    .mega-team-case-5<?php echo $some_id; ?>:hover {
        border: 1px solid <?php echo $member_clr; ?> !important;
    }
</style>