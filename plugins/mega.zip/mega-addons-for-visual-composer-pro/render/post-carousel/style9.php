<div class="col-1-<?php echo $grid; ?> mason-item" style="padding-right: <?php echo $img_padding; ?>px;">
  <figure class="carousel-style8 rpc-box <?php echo $css_class; ?>">
    <div class="image">
      <a href="<?php the_permalink(); ?>">
        <?php the_post_thumbnail('large', array('style' => 'height:'.$height.'px;')); ?>
      </a>
    </div>
    <figcaption class="rpc-overlay" style="opacity: 0.8; background: <?php echo $themeclr ?>;">
      <div class="date rpc-date" style="color: <?php echo $dateclr; ?>;">
      	<span class="day"><?php echo get_the_date( 'd' ); ?></span>
      	<span class="month"><?php echo get_the_date( 'M' ); ?></span>
      </div>
      <h3 class="rpc-title" style="font-size: <?php echo $txtsize; ?>px; color: <?php echo $txtclr ?>"><?php echo get_the_title() ?></h3>
      <p class="rpc-content" style="font-size: <?php echo $descsize; ?>px;">
        <?php $content = get_the_content();
        $content = apply_filters('the_content', $content);
        $content = str_replace(']]>',']]&gt;', $content);
        echo substr(strip_tags($content),0,$excerpt); ?> ...
      </p>
    </figcaption>
    <a href="<?php the_permalink(); ?>" class="read-more " tabindex="0"></a>
  </figure>
</div>