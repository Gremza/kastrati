<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_whatsapp_son extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'btn_text'			=>		'Start a Conversation',
			'btn_tooltip_text'	=>		'Chat with me via WhatsApp',
			'btn_name'			=>		'Michael Scolfield',
			'btn_prof'			=>		'Assistant Manager',
			'status'			=>		'schedule',
			'status_text'		=>		'Online',
			'btn_phone_number'	=>		'',
			'btn_wa_text'		=>		'',
			'image_id'			=>		'',
			'icon_size'			=>		'',
			'text_typography'	=>		'',
			'start_time'		=>		'01:00',
			'end_time'			=>		'21:00',
			'timezone'			=>		'+0',
		), $atts ) );
		$some_id = rand(5, 500);
		if ($image_id != '') {
			$image_url = wp_get_attachment_url( $image_id );		
		}
		$content = wpb_js_remove_wpautop($content, true);
		ob_start(); 
		global $global_whatsapp_style;
		?>



		<!-- For Specific Time -->
		<?php
		$starttime =  $start_time; $endtime = $end_time;
		$start_replace = substr_replace($starttime, ":".'', 2, 0);
		$end_replace = substr_replace($endtime, ":".'', 2, 0);

		$tz = $timezone; $timestamp = time();
		$dt = new DateTime("now", new DateTimeZone($tz));
		$dt->setTimestamp($timestamp);
		$timeupdate = $dt->format('H:i');

		if ($global_whatsapp_style == "wa_btn_lightbox") { ?>
			<div class="wa_popup_member_list">
                <div class="wa_popup_content_item ">
                    <a href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank" 
                    class="wa__stt <?php if ($status == "offline" || $status == "schedule" && $timeupdate < $starttime || $status == "schedule" && $timeupdate > $endtime) { ?> wa__stt_offline <?php } ?>">
                        <div class="wa_popup_avatar">
                            <div class="wa_cs_img_wrap" style="background: url(<?php echo $image_url; ?>) center center no-repeat; background-size: cover;"></div>
                        </div>     
                        <div class="wa_member_txt">
                            <div class="wa_member_name">
            					<?php echo $btn_name; ?>
                            </div>    
                            <div class="wa_member_prof">
                                <?php echo $btn_prof; ?>
                            </div>
                            <?php if ($status == "offline" || $status == "schedule") { ?>
	                            <div class="wa_member_status">
	                                <?php if ($status == "offline") {
			                 			echo $status;
									}
									if ($status == "schedule" && $timeupdate < $starttime || $status == "schedule" && $timeupdate > $endtime) {
			                 			echo "Available from $starttime to $endtime UTC$timezone";
									}
									if ($status == "schedule" && $timeupdate >= $starttime && $timeupdate <= $endtime) {
			                 			echo "<span style='color: #268034;'>Available from $starttime to $endtime UTC$timezone<span>";
									} ?>
	                            </div>
	                        <?php } ?>
                        </div>    
                    </a>
                </div>
            </div>
		<?php } ?>
		
		<?php if ($global_whatsapp_style == "wa_btn_lightbox_2") { ?>
			<div class="wa_popup_support_person" <?php if ($status == "offline" || $status == "schedule" && $timeupdate < $starttime || $status == "schedule" && $timeupdate > $endtime) { ?> 
			style="cursor: not-allowed;" <?php } ?>>
				<?php if ($status == "online") { ?>
					<a href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank">
		        <?php } ?>
	              	<div class="wa_support_person_img_sc">
	                 	<img class="wa_person_img" src="<?php echo $image_url; ?>" style="width: 54px;">
	                 	<?php if ($status == "online" || $status == "schedule" && $timeupdate >= $starttime && $timeupdate <= $endtime) { ?>
	                 		<div class="wa_person_available"></div>
	                 	<?php }
						if ($status == "offline" || $status == "schedule" && $timeupdate < $starttime || $status == "schedule" && $timeupdate > $endtime) { ?>
	                 		<div class="wa_support_person_away"></div>
	                 	<?php } ?>
	              	</div>
	              	<div class="wa_person_info_wrapper">
	                 	<div class="wa_person_title"><?php echo $btn_prof; ?></div>
	                 	<div class="wa_person_name"><?php echo $btn_name; ?></div>
	                 	<div class="wws_person_status">
							<?php if ($status == "online" || $status == "offline") {
	                 			echo $status;
							}
							if ($status == "schedule") {
	                 			echo "Available from $starttime to $endtime UTC$timezone";
							} ?>
	                 	</div>
	              	</div>
		        <?php if ($status == "online") { ?>
					</a>
				<?php } ?>
	        </div>
		<?php } ?>

		<?php return ob_get_clean();
	}
}


vc_map( array(
	"base" 			=> "whatsapp_son",
	"name" 			=> __( 'WhatsApp Settings', 'megaaddons' ),
	"as_child" 		=> array('only' => 'whatsapp_wrap'),
	"content_element" => true,
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Get instant messages from your website', 'megaaddons'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/whatsapp.png',
	'params' => array(
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Choose Image', 'megaaddons' ),
			"param_name" 	=> 	"image_id",
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Name', 'megaaddons' ),
			"param_name" 	=> 	"btn_name",
			"value"			=> 'Michael Scolfield',
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Professional', 'megaaddons' ),
			"param_name" 	=> 	"btn_prof",
			"value"			=> 'Assistant Manager',
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'WhatsApp Phone Number', 'megaaddons' ),
			"param_name" 	=> 	"btn_phone_number",
			"value"			=> '+50235473364',
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'WhatsApp Text', 'megaaddons' ),
			"param_name" 	=> 	"btn_wa_text",
			"value"			=> 'Hello, I have visit Shortcode and I need help from you. Here is link https://elementor.topdigitaltrends.net',
			"group" 		=> 'General',
		),

		// =================== Schedule Settings ====================== >>
		
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Status', 'megaaddons' ),
			"param_name" 	=> 	"status",
			"group" 		=> 'Availability',
			"value"			=> array(
				"Shedule"	=>	"schedule",
				"Online"	=>	"online",
				"Offline"	=>	"offline",
			)
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Online/Offline Text', 'megaaddons' ),
			"param_name" 	=> 	"status_text",
			"value"			=> 'Online',
			"dependency" 	=> array('element' => "status", 'value' => array('online', 'offline')),
			"group" 		=> 'Availability',
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'From', 'megaaddons' ),
			"param_name" 	=> 	"start_time",
			"edit_field_class" => "vc_col-sm-6",
			"dependency" 	=> array('element' => "status", 'value' => 'schedule'),
			"value"			=> '01:00',
			"group" 		=> 'Availability',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'To', 'megaaddons' ),
			"param_name" 	=> 	"end_time",
			"edit_field_class" => "vc_col-sm-6",
			"dependency" 	=> array('element' => "status", 'value' => 'schedule'),
			"value"			=> '20:00',
			"group" 		=> 'Availability',
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Timezone', 'megaaddons' ),
			"param_name" 	=> 	"timezone",
			"edit_field_class" => "vc_col-sm-6",
			"dependency" 	=> array('element' => "status", 'value' => 'schedule'),
			"group" 		=> 'Availability',
			"value"			=> array(
				"UTC-12:00"			=>	"-12",
				"UTC-11:30"			=>	"-11:30",
				"UTC-11"			=>	"-11",
				"UTC-10:30"			=>	"-10:30",
				"UTC-10"			=>	"-10",
				"UTC-9:30"			=>	"-9:30",
				"UTC-9"				=>	"-9",
				"UTC-8:30"			=>	"-8:30",
				"UTC-8"				=>	"-8",
				"UTC-7:30"			=>	"-7:30",
				"UTC-7"				=>	"-7",
				"UTC-6:30"			=>	"-6:30",
				"UTC-6"				=>	"-6",
				"UTC-5:30"			=>	"-5:30",
				"UTC-5"				=>	"-5",
				"UTC-4:30"			=>	"-4:30",
				"UTC-4"				=>	"-4",
				"UTC-3:30"			=>	"-3:30",
				"UTC-3"				=>	"-3",
				"UTC-2:30"			=>	"-2:30",
				"UTC-2"				=>	"-2",
				"UTC-1:30"			=>	"-1:30",
				"UTC-1"				=>	"-1",
				"UTC-0:30"			=>	"-0:30",
				"UTC+0"				=>	"+0",
				"UTC+0:30"			=>	"+0:30",
				"UTC+1"				=>	"+1",
				"UTC+1:30"			=>	"+1:30",
				"UTC+2"				=>	"+2",
				"UTC+2:30"			=>	"+2:30",
				"UTC+3"				=>	"+3",
				"UTC+3:30"			=>	"+3:30",
				"UTC+4"				=>	"+4",
				"UTC+4:30"			=>	"+4:30",
				"UTC+5"				=>	"+5",
				"UTC+5:30"			=>	"+5:30",
				"UTC+5:45"			=>	"+5.45,",
				"UTC+6"				=>	"+6,",
				"UTC+6:30"			=>	"+6:30",
				"UTC+7"				=>	"+7",
				"UTC+7:30"			=>	"+7:30",
				"UTC+8"				=>	"+8",
				"UTC+8:30"			=>	"+8:30",
				"UTC+8:45"			=>	"+8.45",
				"UTC+9"				=>	"+9",
				"UTC+9:30"			=>	"+9:30",
				"UTC+10"			=>	"+10",
				"UTC+10:30"			=>	"+10:30",
				"UTC+11"			=>	"+11",
				"UTC+11:30"			=>	"+11:30",
				"UTC+12"			=>	"+12",
				"UTC+12:45"			=>	"+12.45",
				"UTC+13"			=>	"+13",
				"UTC+13:45"			=>	"+13.45",
				"UTC+14"			=>	"+14",
			)
		),

		
	)
) 
);
