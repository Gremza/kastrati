<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_vc_360product extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'image_ids' 		=> 		'test',
			'img_width' 		=> 		'',
			'img_height' 		=> 		'',
			'animate' 			=> 		'',
			'loop' 				=> 		'',
			'reverse' 			=> 		'',
			'retainanimate' 	=> 		'',
			'frame' 			=> 		'1',
			'frametime' 		=> 		'60',
			'behavior' 			=> 		'drag',
			'slider' 			=> 		'',
			'slider_gap' 		=> 		'10',
			'ease' 				=> 		'',
			'blur' 				=> 		'',
			'fullscreen' 		=> 		'',
			'icon_ps' 			=> 		'iconps-top-right',
			'iconclr' 			=> 		'',
			'iconbg' 			=> 		'',
			'iconboder_radius' 	=> 		'',

		), $atts ) );
		$some_id = rand(5, 500);
		wp_enqueue_style( 'spritespin-css', plugins_url( '../css/spritespin.css' , __FILE__ ));
		wp_enqueue_script( 'spritespin-js', plugins_url( '../js/spritespin.js' , __FILE__ ));
		wp_enqueue_script( 'custom-spritespin-js', plugins_url( '../js/front-js/custom_spritespin.js' , __FILE__ ));
		$content = wpb_js_remove_wpautop($content, true);
		ob_start(); ?>

		<?php
		    if ($image_ids != '') {
		    	$all_images = explode(',', $image_ids);
		    	$count = 0;
		        foreach ($all_images as $image) {
		        	$image_url = wp_get_attachment_url( $image );
	           		if($count == 0)
	           			$images = $image_url;
	           		if($count > 0)
	           			$images .= ",".$image_url;
	           		$count = 1;
		        }
		    }
		?>
		
		<div class="mySpriteSpinWrapper mySpriteSpin_<?php echo $some_id; ?>">
		    <div class="mySpriteSpin"
		    	data-animate="<?php echo $animate; ?>" 
		    	data-loop="<?php echo $loop; ?>" 
		    	data-reverse="<?php echo $reverse; ?>"
		    	data-retainanimate="<?php echo $retainanimate; ?>"
		    	data-frame="<?php echo $frame; ?>"
		    	data-frametime="<?php echo $frametime; ?>"
				data-behavior="<?php echo $behavior; ?>"
				data-slider="<?php echo $slider; ?>"
				data-fullscreen="<?php echo $fullscreen; ?>"
				data-ease="<?php echo $ease; ?>"
				data-blur="<?php echo $blur; ?>"
				data-images="<?php echo $images; ?>"
				>
			</div>
			<?php if ($fullscreen != '') { ?>
				<a class="button js-fullscreen <?php echo $icon_ps; ?>" href="#" style="color: <?php echo $iconclr ?>; background: <?php echo $iconbg ?>; border-radius: <?php echo $iconboder_radius ?>px;">
					<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-svg="search"><circle fill="none" stroke="#fff" stroke-width="1.1" cx="9" cy="9" r="7"></circle><path fill="none" stroke="#fff" stroke-width="1.1" d="M14,14 L18,18 L14,14 Z"></path></svg>
				</a>
			<?php } ?>
			
			<?php if ($slider != '') { ?>
				<input class="spritespin-slider" style="margin-top: <?php echo $slider_gap; ?>px;" type="range">
			<?php } ?>
		</div>

		<style>
			<?php if ($img_width != '') { ?>
				@media only screen and (min-width: 720px) {
					.mySpriteSpin_<?php echo $some_id; ?> {
						display: block;
					    margin: auto;
					    width: <?php echo $img_width; ?>px;
					}
					.mySpriteSpin_<?php echo $some_id; ?> .mySpriteSpin {
						width: <?php echo $img_width; ?>px;
					}
				}
			<?php } ?>
		</style>

		<?php
		return ob_get_clean();
	}
}


vc_map( array(
	"name" 			=> __( '360 Product Viewer', '360view' ),
	"base" 			=> "vc_360product",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Turns image frames into 360 degree view of product.', '360view'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/360view.png',
	'params' => array(
		array(
			"type" 			=> 	"attach_images",
			"heading" 		=> 	__( 'Images', '360view' ),
			"param_name" 	=> 	"image_ids",
			"description" 	=> 	__( 'Select the images that will be used as product viewer <a href="https://addons.topdigitaltrends.net/360-product-viewer/" target="_blank">See Demo</a>', 'photobook' ),
			"group" 		=> 	'General',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Image Width', '360view' ),
			"param_name" 	=> "img_width",
			"suffix" 		=> 'px',
			"group" 		=> 'General',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urls",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Slider Settings</span>', 'ihover' ),
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Slider', '360view' ),
			"param_name" 	=> 	"slider",
			"description" 	=> 	__( 'move product viewer with slider', '360view' ),
			"group" 		=> 	'General',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Slider Image Gap', '360view' ),
			"param_name" 	=> 	"slider_gap",
			"dependency" => array('element' => "slider", 'value' => 'true'),
			"suffix" 		=> 	'px',
			"group" 		=> 	'General',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urlss",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Full Screen Button Settings</span>', 'ihover' ),
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Full Screen', '360view' ),
			"param_name" 	=> 	"fullscreen",
			"description" 	=> 	__( 'show full screen button', '360view' ),
			"group" 		=> 	'General',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Icon Position', '360view' ),
			"param_name" 	=> 	"icon_ps",
			"dependency" 	=> array('element' => "fullscreen", 'value' => 'true'),
			"group" 		=> 	'General',
			"value" 		=> array(
				"Top Right"		=> "iconps-top-right", 
				"Top Left" 		=> "iconps-top-left",
				"Bottom Right" 	=> "iconps-bottom-right",
				"Bottom Left" 	=> "iconps-bottom-left",
			)
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Icon Color', '360view' ),
			"param_name" 	=> 	"iconclr",
			"edit_field_class" => "vc_col-sm-4",
			"dependency" => array('element' => "fullscreen", 'value' => 'true'),
			"group" 		=> 	'General',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Icon Background', '360view' ),
			"param_name" 	=> 	"iconbg",
			"dependency" => array('element' => "fullscreen", 'value' => 'true'),
			"edit_field_class" => "vc_col-sm-4",
			"group" 		=> 	'General',
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Border Radius', '360view' ),
			"param_name" 	=> 	"iconboder_radius",
			"edit_field_class" => "vc_col-sm-4",
			"dependency" => array('element' => "fullscreen", 'value' => 'true'),
			"suffix" 		=> 	'px',
			"group" 		=> 	'General',
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Animate', '360view' ),
			"param_name" 	=> 	"animate",
			"description" 	=> 	__( 'If true, starts the animation automatically on load', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Loop', '360view' ),
			"param_name" 	=> 	"loop",
			"description" 	=> 	__( 'If true, continues playback in a loop.', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Reverse', '360view' ),
			"param_name" 	=> 	"reverse",
			"description" 	=> 	__( 'If true, animation playback is reversed', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Retain Animate', '360view' ),
			"param_name" 	=> 	"retainanimate",
			"description" 	=> 	__( 'If true, retains the animation after user iser interaction', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "true",
			)
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Frame', '360view' ),
			"param_name" 	=> 	"frame",
			"description" 	=> 	__( 'Initial frame number.', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=>  "1",
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'FrameTime', '360view' ),
			"param_name" 	=> 	"frametime",
			"description" 	=> 	__( 'Time in ms between updates. e.g. 40 is exactly 25 FPS', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=>  "60",
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Behavior', '360view' ),
			"param_name" 	=> 	"behavior",
			"description" 	=> 	__( 'Direction of the overall page organization', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
				"Drag"			=> "drag", 
				"Mouse Move" 	=> "move",
				"Mouse Wheel" 	=> "wheel",
			)
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Ease', '360view' ),
			"param_name" 	=> 	"ease",
			"description" 	=> 	__( 'module that eases out an animation after mouse is released', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "ease",
			)
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Blur', '360view' ),
			"param_name" 	=> 	"blur",
			"description" 	=> 	__( 'module that render and fades additional frames to somulate blur', '360view' ),
			"group" 		=> 	'Options',
			"value" 		=> array(
					"Enable"		=> "blur",
			)
		),

	),
) );