<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_vc_interective_banner extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'			=>		'',
			'align'			=>		'center',
			'desc'			=>		'',
			'icon'			=>		'none',
			'banner_icon'	=>		'',
			'image_id'		=>		'',
			'alt'			=>		'',
			'height'		=>		'none',
			'height_value'	=>		'',
			'link'			=>		'none',
			'url'			=>		'',
			'effects'		=>		'banner-style01',
			'bgclr'			=>		'',
			'class'			=>		'',
			'title_clr'		=>		'',
			'title_bg'		=>		'',
			'desc_clr'		=>		'',
			'title_size'	=>		'14',
			'desc_size'		=>		'14',
		), $atts ) );
		$url = vc_build_link($url);
		if ($image_id != '') {
			$image_url = wp_get_attachment_url( $image_id );		
		}
		$content = wpb_js_remove_wpautop($content, true);
		wp_enqueue_style( 'vc-int-banner-css', plugins_url( '../css/int_banner2.css' , __FILE__ ));
		ob_start(); ?>
		
		<div class="mega-int-banner-2 <?php echo $link; ?> <?php echo $effects; ?> <?php echo $class; ?>">
			<img src="<?php echo $image_url ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height_value; ?>px;">
			<h3 class="title-center bb-top-title ult-responsive" style="background: <?php echo $title_bg; ?>; color: <?php echo $title_clr; ?>; text-align: <?php echo $align; ?>">
				<?php echo $title; ?>
				<?php if ($icon == 'heading' || $icon == 'both') { ?>
					<i class="fa <?php echo $banner_icon ?>" style="color: <?php echo $title_clr; ?>; padding-right: 25px;"></i>
				<?php } ?>
			</h3>
			<div class="mask opaque-background" style="background:rgba(36,36,36,0.4);">
				<div class="bb-description ult-responsive" style="color: <?php echo $desc_clr; ?>; font-size: <?php echo $desc_size ?>px;">
					<div class="bb-back-icon">
						<?php if ($icon == 'desc' || $icon == 'both') { ?>
							<i class="fa <?php echo $banner_icon ?>" style="color: <?php echo $title_clr; ?>;"></i>
						<?php } ?>
					</div>
					<?php echo $desc; ?>
				</div>
				<?php if ($link == 'mega-int-btn') { ?>
					<a class="bb-link" href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>" title="<?php echo esc_html($url['title']); ?>" style="background:rgba(36,36,36,0.4);color:#ffffff;">READ MORE</a>
				<?php } ?>
			</div>
			<?php if ($link == 'mega-int-box') {
				if (!empty($url)) { ?>
					<a class="bb-link" href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>" title="<?php echo esc_html($url['title']); ?>"></a>
				<?php } ?>
			<?php } ?>
		</div>

		<?php
		return ob_get_clean();
	}
}


vc_map( array(
	"name" 			=> __( 'Interactive Banner 2', 'int_banner2' ),
	"base" 			=> "vc_interective_banner",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Display image with information', 'int_banner2'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/int-banner2.png',
	'params' => array(
		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Interactive Banner Title', 'int_banner2' ),
			"param_name" 	=> 	"title",
			"description" 	=> 	__( 'Give a title to this banner', 'int_banner2' ),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Banner Title Location', 'int_banner2' ),
			"param_name" 	=> 	"align",
			"description" 	=> 	__( 'Alignment of the title.', 'int_banner2' ),
			"group" 		=> 	'General',
			"value"			=> array(
				"Title on Center"	=> "center",
				"Title on Left"	=> "left",
			)
        ),
        array(
            "type" 			=> 	"textarea",
			"heading" 		=> 	__( 'Banner Description', 'int_banner2' ),
			"param_name" 	=> 	"desc",
			"description" 	=> 	__( 'Text that comes on mouse hover.', 'int_banner2' ),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Use Icon', 'int_banner2' ),
			"param_name" 	=> 	"icon",
			"description" 	=> 	__( 'Alignment of the title.', 'int_banner2' ),
			"group" 		=> 	'General',
			"value"			=> array(
				"None"					=> "none",
				"Icon With Heading"		=> "heading",
				"Icon With Description"	=> "desc",
				"Both"					=> "both",
			)
        ),
        array(
            "type" 			=> 	"iconpicker",
			"heading" 		=> 	__( 'Select Icon', 'int_banner2' ),
			"param_name" 	=> 	"banner_icon",
			"description" 	=> 	__( 'Click and select icon of your choice.', 'int_banner2' ),
			"dependency" => array('element' => "icon", 'value' => array('heading', 'desc', 'both')),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Upload Image', 'int_banner2' ),
			"param_name" 	=> 	"image_id",
			"description" 	=> 	__( 'Upload the image for this banner', 'int_banner2' ),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Alternate Text', 'info-banner-vc' ),
			"param_name" 	=> 	"alt",
			"description" 	=> 	__( 'It will be used as alt attribute of img tag', 'info-banner-vc' ),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Banner height Type', 'int_banner2' ),
			"param_name" 	=> 	"height",
			"description" 	=> 	__( 'Selct between Auto or Custom height for Banner.', 'int_banner2' ),
			"group" 		=> 	'General',
			"value"			=> array(
				"Auto Height"		=> "none",
				"Custom height"		=> "block",
			)
        ),
        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Banner height Value', 'int_banner2' ),
			"param_name" 	=> 	"height_value",
			"description" 	=> 	__( 'Give height in pixels for interactive banner. eg 200', 'int_banner2' ),
			"suffix" 		=> 'px',
			"max"			=>	"",
			"dependency" => array('element' => "height", 'value' => 'block'),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Apply link to:', 'int_banner2' ),
			"param_name" 	=> 	"link",
			"description" 	=> 	__( 'Select whether to use color for icon or not.', 'int_banner2' ),
			"group" 		=> 	'General',
			"value"			=> array(
				"None Link"				=> "none",
				"Complete Box"			=> "mega-int-box",
				"Display Read More"		=> "mega-int-btn",
			)
        ),
        array(
            "type" 			=> 	"vc_link",
			"heading" 		=> 	__( 'Banner Link', 'int_banner2' ),
			"param_name" 	=> 	"url",
			"description" 	=> 	__( 'Add link to this banner', 'int_banner2' ),
			"dependency" => array('element' => "link", 'value' => array('mega-int-box', 'mega-int-btn')),
			"group" 		=> 	'General',
        ),
        array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Box Hover Effects', 'int_banner2' ),
			"param_name" 	=> 	"effects",
			"description" 	=> 	__( 'Select animation effect style for this block.', 'int_banner2' ),
			"group" 		=> 	'General',
			"value"			=> array(
				'Appear From Bottom'    =>      'banner-style01',
				'Appear From Top'      	=>      'banner-style02',
				'Appear From Left'      =>      'banner-style03',
				'Appear From Right'     =>      'banner-style04',
				'Zoom In'      			=>      'banner-style11',
				'Zoom Out'      		=>      'banner-style12',
				'Zoom In-Out'      		=>      'banner-style13',
				'Jump From Left'      	=>      'banner-style21',
				'Jump From Right'      	=>      'banner-style22',
				'Pull From Bottom'      =>      'banner-style31',
				'Pull From Top'      	=>      'banner-style32',
				'Pull From Left'      	=>      'banner-style33',
				'Pull From Right'      	=>      'banner-style34',
			)
        ),
   //      array(
   //          "type" 			=> 	"colorpicker",
			// "heading" 		=> 	__( 'Overlay Background Color', 'int_banner2' ),
			// "param_name" 	=> 	"bgclr",
			// "description" 	=> 	__( 'Select the background color for banner overlay', 'int_banner2' ),
			// "group" 		=> 	'General',
   //      ),
        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Extra Class', 'int_banner2' ),
			"param_name" 	=> 	"class",
			"description" 	=> 	__( 'Add extra class name that will be applied to the icon process, and you can use this class for your customizations.', 'int_banner2' ),
			"group" 		=> 	'General',
        ),

        /* Color
        ============================ */

        array(
            "type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Heading Title Color', 'int_banner2' ),
			"param_name" 	=> 	"title_clr",
			"description" 	=> 	__( 'Select the color for banner heading', 'int_banner2' ),
			"group" 		=> 	'Color',
        ),
        array(
            "type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Heading Background Color', 'int_banner2' ),
			"param_name" 	=> 	"title_bg",
			"description" 	=> 	__( 'Select the background color for banner heading', 'int_banner2' ),
			"group" 		=> 	'Color',
        ),
        array(
            "type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Descrption Color', 'int_banner2' ),
			"param_name" 	=> 	"desc_clr",
			"description" 	=> 	__( 'Select the Description color for banner', 'int_banner2' ),
			"group" 		=> 	'Color',
        ),

        /* Settings
        ============================ */

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Title Font Size', 'int_banner2' ),
			"param_name" 	=> 	"title_size",
			"description" 	=> 	__( 'set in pixel eg 14.', 'int_banner2' ),
			"value"			=>	"14",
			"suffix" 		=> 'px',
			"group" 		=> 	'Settings',
        ),
        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Description Font Size', 'int_banner2' ),
			"param_name" 	=> 	"desc_size",
			"description" 	=> 	__( 'set in pixel eg 14.', 'int_banner2' ),
			"value"			=>	"14",
			"suffix" 		=> 'px',
			"group" 		=> 	'Settings',
        ),

	),
) );

