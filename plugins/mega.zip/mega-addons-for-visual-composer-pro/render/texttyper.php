<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_text_type_vc extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'align'	 		=> 'left',
			'typespeed' 	=> '70',
			'backspeed' 	=> '500',
			'loop' 			=> '',
			'verticalclr' 	=> '#000',
			'typerclr' 		=> '',
			'typerbg' 		=> '',
			'checked' 		=> '',
			'before'		=>	'',
			'after'			=>	'',
			'size'			=>	'18',
			'textmblsize'	=>	'18',
			'typersize'		=>	'18',
			'typermblsize'	=>	'18',
			'typer_padding'	=>	'',
			'typer_lineheight'	=>	'',
			'clr'			=>	'',
			'use_theme_fonts'=>		'',
			'google_fonts'	=>		'default',
		), $atts ) );
		$some_id = rand(5, 500);
		$content = wpb_js_remove_wpautop($content, true);
		wp_enqueue_script( 'typed-js', plugins_url( '../js/typed.js' , __FILE__ ), array('jquery', 'jquery-ui-core'));
		wp_enqueue_script( 'typer-js', plugins_url( '../js/customTyper.js' , __FILE__ ), array('jquery', 'jquery-ui-core'));
		wp_localize_script( 'typer-js', 'mega_text', array(
			'typespeed' => $typespeed,
			'backspeed' => $backspeed,
		) );
		$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
		$googleallfonts = "";
		if($google_fonts != "default"){
			$fontsData = $this->getFontsData( $atts, 'google_fonts' );
			$googleFontsStyles = $this->googleFontsStyles( $fontsData );
			$this->enqueueGoogleFonts( $fontsData );
			if (empty($googleFontsStyles) == false){
				$googleallfonts = esc_attr( implode( ';', $googleFontsStyles ) );
			} else {
				$googleallfonts = $googleFontsStyles;
			}
		}
		ob_start(); ?>
		<!-- HTML DESIGN HERE -->

		<div class="type-wrap type-wrap-<?php echo $some_id; ?>"
			data-typespeed="<?php echo $typespeed; ?>"
			data-backspeed="<?php echo $backspeed; ?>"
			data-loop="<?php echo $loop; ?>"
			style="height: 50px; text-align: <?php echo $align; ?>;">
			<span class="mega-prefix" style="font-size: <?php echo $size; ?>px; color: <?php echo $clr; ?>;"> 
				<?php echo $before; ?>
			</span>
            <div class="typed-strings">
                <?php echo $content; ?>
            </div>
            <div style="background: <?php echo $typerbg; ?>; padding: <?php echo $typer_padding; ?>; line-height: <?php echo $typer_lineheight; ?>; display: inline-block;">
	            <span class="typed" style="white-space:pre; color: <?php echo $typerclr; ?>; font-size: <?php echo $typersize; ?>px;"></span>
	            <?php if (!empty($checked)) { ?>
	            	<span class="blink_me" style="color: <?php echo $verticalclr; ?>; font-size: <?php echo $typersize; ?>px">|</span>	            	
	            <?php } ?>
	        </div>
	        <span class="mega-suffix" style="font-size: <?php echo $size; ?>px;color: <?php echo $clr; ?>;"> 
	        	<?php echo $after; ?>
	        </span>
        </div>

        <style>
        	.type-wrap-<?php echo $some_id; ?> *{
        	 	<?php echo $googleallfonts; ?>;
        	}
			@media only screen and (max-width: 768px) {
				.type-wrap-<?php echo $some_id; ?> .typed,
				.type-wrap-<?php echo $some_id; ?> .blink_me {
					font-size: <?php echo $typermblsize; ?>px !important;
				}

				.type-wrap-<?php echo $some_id; ?> .mega-prefix,
				.type-wrap-<?php echo $some_id; ?> .mega-suffix {
					font-size: <?php echo $textmblsize; ?>px !important;
				}
			}
        </style>

        <!-- HTML END DESIGN HERE -->
		<?php 
		return ob_get_clean();
	}

	protected function getFontsData( $atts, $paramName ) {
		$googleFontsParam = new Vc_Google_Fonts();
		$field = WPBMap::getParam( $this->shortcode, $paramName );
		$fieldSettings = isset( $field['settings'], $field['settings']['fields'] ) ? $field['settings']['fields'] : array();
		$fontsData = strlen( $atts[ $paramName ] ) > 0 ? $googleFontsParam->_vc_google_fonts_parse_attributes( $fieldSettings, $atts[ $paramName ] ) : '';

		return $fontsData;
	}

	protected function googleFontsStyles( $fontsData ) {
		// Inline styles
		$fontFamily = explode( ':', $fontsData['values']['font_family'] );
		$styles[] = 'font-family:' . $fontFamily[0];
		$fontStyles = explode( ':', $fontsData['values']['font_style'] );
		if(count($fontStyles)>1){
			$styles[] = 'font-weight:' . $fontStyles[1];
			$styles[] = 'font-style:' . $fontStyles[2];
			return $styles;
		} else {
			return "";
		}

	}

	protected function enqueueGoogleFonts( $fontsData ) {
		// Get extra subsets for settings (latin/cyrillic/etc)
		$settings = get_option( 'wpb_js_google_fonts_subsets' );
		if ( is_array( $settings ) && ! empty( $settings ) ) {
			$subsets = '&subset=' . implode( ',', $settings );
		} else {
			$subsets = '';
		}

		// We also need to enqueue font from googleapis
		if ( isset( $fontsData['values']['font_family'] ) ) {
			wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $fontsData['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $fontsData['values']['font_family'] . $subsets );
		}
	}
}


vc_map( array(
	"name" 			=> __( 'Text Type', 'text_type_vc' ),
	"base" 			=> "text_type_vc",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Fancy line with animation effects', ''),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/texttype.png',
	'params' => array(
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Text Align', 'texttype_vc' ),
			"param_name" 	=> 	"align",
			"description" 	=> 	__( 'set text align <a href="https://addons.topdigitaltrends.net/texttype-effects/" target="_blank">See Demo</a>', 'texttype_vc' ),
			"group" 		=> 	'General',
			"value"			=>	array(
				"Left" 			=> 	"left",
				"Center" 		=> 	"center",
				"Right" 		=> 	"right",
			)
		),
		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'Prefix', 'texttype_vc' ),
			"param_name" 	=> 	"before",
			"description" 	=> 	__( 'write text that will show before typer text or leave blank', 'texttype_vc' ),
			"group" 		=> 	'General',
		),
		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'Suffix', 'texttype_vc' ),
			"param_name" 	=> 	"after",
			"description" 	=> 	__( 'write text that will show after typer text or leave blank', 'texttype_vc' ),
			"group" 		=> 	'General',
		),
		
		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Show Vertical line |', 'texttype_vc' ),
			"param_name" 	=> 	"checked",
			"description" 	=> 	__( 'with and after typer text', 'texttype_vc' ),
			"group" 		=> 	'Typer Text',
		),
		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Vertical line Color', 'texttype_vc' ),
			"param_name" 	=> 	"verticalclr",
			"group" 		=> 	'Typer Text',
		),
		array(
			"type" 			=> 	"textarea_html",
			"heading" 		=> 	__( 'Provide text to display (each per line) [ Text must be wrapped in html markup ]', 'texttype_vc' ),
			"param_name" 	=> 	"content",
			"description" 	=> 	__( 'Text must be wrapped in html markup.', 'texttype_vc' ),
			'value' 		=> __( "I'm hello world", 'texttype_vc' ),
			"group" 		=> 	'Typer Text',
		),


		// --------------------- TextTyper Settings ------------------------ >

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Text type speed', 'texttype_vc' ),
			"param_name" 	=> 	"typespeed",
			"description" 	=> 	__( 'in milli second, default 70 [1s = 1000]', 'texttype_vc' ),
			"max"			=>	"",
			'value' 		=> __( "70", 'texttype_vc' ),
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Back delay speed', 'texttype_vc' ),
			"param_name" 	=> 	"backspeed",
			"description" 	=> 	__( 'in milli second, default 500 [1s = 1000]', 'texttype_vc' ),
			"max"			=>	"",
			'value' 		=> __( "500", 'texttype_vc' ),
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Loop', 'texttype_vc' ),
			"param_name" 	=> 	"loop",
			"description" 	=> 	__( 'Repeat text', 'texttype_vc' ),
			"group" 		=> 	'Settings',
			'value' 		=> 	 array( 'true', 'false' ),
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urls",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Prefix/Suffix Typography</span>', 'megaaddons' ),
			"group" 		=> 'Settings',
		),

		array(
			"type"             => "text",
			"param_name"       => "wdo_title_text_typography",
			"heading"          => "<b>" . __( "Prefix/Suffix Text [Font Size]", "wdo-carousel" ) . "</b>",
			"value"            => "",
			"edit_field_class" => "vc_col-sm-12 wdo_margin_top",
			"group"            => "Settings"
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'On Desktop', 'texttype_vc' ),
			"edit_field_class" => "vc_col-sm-4 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"size",
			"suffix" 		=> 'px',
			'value' 		=> __( "18", 'texttype_vc' ),
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'On Mobile', 'slider' ),
			"edit_field_class" => "vc_col-sm-4 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"textmblsize",
			"suffix" 		=> 'px',
			"value"			=>	"18",
			"group" 		=> 'Settings',
		),
		
		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Text Color', 'texttype_vc' ),
			"param_name" 	=> 	"clr",
			"group" 		=> 	'Settings',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urls",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">TextTyper Typography</span>', 'megaaddons' ),
			"group" 		=> 'Settings',
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Padding', 'texttype_vc' ),
			"param_name" 	=> 	"typer_padding",
			"description" 	=> 	"top right bottom left",
			'value' 		=> __( "0px 0px 0px 0px", 'texttype_vc' ),
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"colorpicker",
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"heading" 		=> 	__( 'Typer Color', 'texttype_vc' ),
			"param_name" 	=> 	"typerclr",
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"colorpicker",
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"heading" 		=> 	__( 'Typer Background', 'texttype_vc' ),
			"param_name" 	=> 	"typerbg",
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'FontSize [On Desktop]', 'texttype_vc' ),
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"typersize",
			"suffix" 		=> 'px',
			'value' 		=> __( "18", 'texttype_vc' ),
			"group" 		=> 	'Settings',
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'On Mobile', 'slider' ),
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"typermblsize",
			"suffix" 		=> 'px',
			"value"			=>	"18",
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Line Height', 'slider' ),
			// "edit_field_class" => "vc_col-sm-4 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"typer_lineheight",
			"value"			=>	"1",
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urlsss",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Google Fonts Option</span>', 'ihover' ),
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Use theme default font family?', 'creativelink' ),
			"param_name" 	=> 	"use_theme_fonts",
			"description" 	=> 	__( 'Use font family from the theme.', 'creativelink' ),
			"group" 		=> 	'Settings',
			"value" 		=> array(
					"Yes"		=> "yes",
			)
		),

		array(
			'type' => 'google_fonts',
			'param_name' => 'google_fonts',
			'value' => 'default',
			'settings' => array(
				'fields' => array(
					'font_family_description' => __( 'Select font family.', 'js_composer' ),
					'font_style_description' => __( 'Select font styling.', 'js_composer' ),
				),
			),
			"group" 		=> 	'Settings',
			'weight' => 0,
			'dependency' => array(
				'element' => 'use_theme_fonts',
				'value_not_equal_to' => 'yes',
			),
		),
	),
) );

