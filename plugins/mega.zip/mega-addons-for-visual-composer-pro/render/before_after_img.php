<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_vc_before_after extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'image_id'			=>		'',
			'text'				=>		'',
			'image_id2'			=>		'',
			'text2'				=>		'',
			'text_bg'			=>		'',
			'direction'			=>		'horizontal',
			'handle'			=>		'false',
			'onclick'			=>		'true',
			'img_height'		=>		'',
			'img_mbl'			=>		'',
			'boxborderwidth'	=>		'',
			'boxborderradius'	=>		'',
			'boxborderclr'		=>		'',
			'handleradius'		=>		'',
			'handlearrowclr'	=>		'',
			'handlelineclr'		=>		'',
		), $atts ) );
		$some_id = rand(5, 500);
		if ($image_id != '') {
			$image_url = wp_get_attachment_url( $image_id );		
		}
		if ($image_id2 != '') {
			$image_url2 = wp_get_attachment_url( $image_id2 );		
		}
		wp_enqueue_style( 'before-after-css', plugins_url( '../css/twentytwenty.css' , __FILE__ ));
		wp_enqueue_script( 'event-move-js', plugins_url( '../js/jquery.event.move.js' , __FILE__ ), array('jquery'));
		wp_enqueue_script( 'jquery-twenty-js', plugins_url( '../js/jquery.twentytwenty.js' , __FILE__ ), array('jquery'));
		// wp_enqueue_script( 'custom-twenty-js', plugins_url( '../js/custom-after-before.js' , __FILE__ ), array('jquery'));
		$content = wpb_js_remove_wpautop($content, true);
		ob_start(); ?>
		<div class="img-comparison-<?php echo $some_id; ?> mega-before-after-img mega_before_after_img">
			<div class="twentytwenty-container maw_img_comp_container" data-orientation="<?php echo $direction; ?>" style="height: <?php echo $img_height; ?>px;">
	          <img src="<?php echo $image_url; ?>" alt="<?php echo $text ?>" style="width: 100%; height: <?php echo $img_height; ?>px;"/>
		      <img src="<?php echo $image_url2; ?>" alt="<?php echo $text2 ?>" style="width: 100%; height: <?php echo $img_height; ?>px; clip: auto;"/>
	        </div>
	    </div>
        <style>
        	<?php if ($text != '' || $text2 != '') { ?>
				.img-comparison-<?php echo $some_id; ?> .twentytwenty-vertical .twentytwenty-before-label:before,
				.img-comparison-<?php echo $some_id; ?> .twentytwenty-horizontal .twentytwenty-before-label:before {
					background-color: <?php echo $text_bg; ?>;
					content: "<?php echo $text ?>" !important;
				}
				.img-comparison-<?php echo $some_id; ?> .twentytwenty-vertical .twentytwenty-after-label:before,
				.img-comparison-<?php echo $some_id; ?> .twentytwenty-horizontal .twentytwenty-after-label:before {
					background-color: <?php echo $text_bg; ?>;
					content: "<?php echo $text2 ?>" !important;
				}
			<?php } ?>
			<?php if ($boxborderwidth != '' && $boxborderclr != '') { ?>
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container {
					border: <?php echo $boxborderwidth; ?>px solid <?php echo $boxborderclr; ?>;
	    			border-radius: <?php echo $boxborderradius; ?>px;
				}
			<?php } ?>
			<?php if ($handlelineclr != '') { ?>
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-handle:before,
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-handle:after {
					background: <?php echo $handlelineclr; ?>;
				}
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-handle {
					border: 3px solid <?php echo $handlelineclr; ?>;
					border-radius: <?php echo $handleradius; ?>px;
					background: <?php echo $handlelineclr; ?>;
				}
			<?php } ?>
			<?php if ($handlearrowclr != '' && $direction == 'horizontal') { ?>
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-left-arrow {
				    border-right: 6px solid <?php echo $handlearrowclr; ?>;
				}
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-right-arrow {
				    border-left: 6px solid <?php echo $handlearrowclr; ?>;
				}
			<?php } ?>
			<?php if ($handlearrowclr != '' && $direction == 'vertical') { ?>
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-down-arrow {
					border-top: 6px solid <?php echo $handlearrowclr; ?>;
				}
				.img-comparison-<?php echo $some_id; ?> .maw_img_comp_container .twentytwenty-up-arrow {
				    border-bottom: 6px solid <?php echo $handlearrowclr; ?>;
				}
			<?php } ?>
			<?php if ($img_mbl != '') { ?>
				@media only screen and (max-width: 768px) {
					.img-comparison-<?php echo $some_id; ?> .twentytwenty-container, 
					.img-comparison-<?php echo $some_id; ?> .twentytwenty-container img{
						height: <?php echo $img_mbl; ?>px !important;
					}
				}
			<?php } ?>
		</style>
		<script>
			jQuery(function(){
		      jQuery(".twentytwenty-container[data-orientation!='vertical']").twentytwenty({default_offset_pct: 0.5});
		      jQuery(".twentytwenty-container[data-orientation='vertical']").twentytwenty({default_offset_pct: 0.5, orientation: 'vertical'});
		    });
		</script>
		<?php
		return ob_get_clean();
	}
}


vc_map( array(
	"name" 			=> __( 'Before After Image', 'before' ),
	"base" 			=> "vc_before_after",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Compare the images', 'before'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/beforeAfter.png',
	'params' => array(
		array(
            "type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Before Image', 'before' ),
			"param_name" 	=> 	"image_id",
			"description" 	=> 	__( 'Select the image', 'before' ),
			"group" 		=> 	'Image',
        ),
        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Before Label', 'before' ),
			"param_name" 	=> 	"text",
			"description" 	=> 	__( 'It will be used as label text and alt attribute of img tag', 'before' ),
			"group" 		=> 	'Image',
        ),
        array(
            "type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'After Image', 'before' ),
			"param_name" 	=> 	"image_id2",
			"description" 	=> 	__( 'Select the image', 'before' ),
			"group" 		=> 	'Image',
        ),
        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'After Label', 'before' ),
			"param_name" 	=> 	"text2",
			"description" 	=> 	__( 'It will be used as label text and alt attribute of img tag', 'before' ),
			"group" 		=> 	'Image',
        ),
        array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Background', 'ihover' ),
			"param_name" 	=> "text_bg",
			"description" 	=> __( 'background color for before after text', 'ihover' ),
			"group" 		=> 'Image',
		),
		array(
			"type"             => "text",
			"param_name"       => "wdo_title_text_typography",
			"heading"          => "<b>" . __( "Image Height", "before" ) . "</b>",
			"value"            => "",
			"edit_field_class" => "vc_col-sm-12 wdo_margin_top",
			"group"            => "Image"
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'On Desktop', 'before' ),
			"edit_field_class" => "vc_col-sm-4 wdo_items_to_show wdo_margin_bottom",
			"suffix" 		=> 'px',
			"param_name" 	=> 	"img_height",
			"group" 		=> 'Image',
		),
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'On Mobile', 'before' ),
			"suffix" 		=> 'px',
			"edit_field_class" => "vc_col-sm-4 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"img_mbl",
			"group" 		=> 'Image',
		),

		array(
            "type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Orientation', 'before' ),
			"param_name" 	=> 	"direction",
			"description" 	=> 	__( 'select slider movement', 'before' ),
			"group" 		=> 	'Settings',
			"value"			=>		array(
				'Horizontal'	=>		'horizontal',
				'Vertical'		=>		'vertical',
			)
        ),

        array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_url",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Container Border Settings</span>', 'ihover' ),
			"group" 		=> 'Settings',
		),

        array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Border Width', 'before' ),
			"param_name" 	=> 	"boxborderwidth",
			"suffix" 		=> 'px',
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Border Radius', 'before' ),
			"param_name" 	=> 	"boxborderradius",
			"suffix" 		=> 'px',
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Border Color', 'before' ),
			"param_name" 	=> 	"boxborderclr",
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_url",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Handle Line Settings</span>', 'ihover' ),
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Handle Line Color', 'before' ),
			"param_name" 	=> 	"handlelineclr",
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Handle Border Radius', 'before' ),
			"param_name" 	=> 	"handleradius",
			"suffix" 		=> 'px',
			"group" 		=> 'Settings',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Handle Arrow Color', 'before' ),
			"param_name" 	=> 	"handlearrowclr",
			"group" 		=> 'Settings',
		),


   //      array(
   //          "type" 			=> 	"dropdown",
			// "heading" 		=> 	__( 'Move Slider On Hover', 'before' ),
			// "param_name" 	=> 	"onhover",
			// "group" 		=> 	'Settings',
			// "value"			=>		array(
			// 	'False'			=>		'false',
			// 	'True'			=>		'true',
			// )
   //      ),
   //      array(
   //          "type" 			=> 	"dropdown",
			// "heading" 		=> 	__( 'Move With Handle', 'before' ),
			// "param_name" 	=> 	"handle",
			// "description" 	=> 	__( 'Allow a user to swipe anywhere on the image to control slider movement.', 'before' ),
			// "group" 		=> 	'Settings',
			// "value"			=>		array(
			// 	'True'			=>		'true',
			// 	'False'			=>		'false',
			// )
   //      ),
   //      array(
   //          "type" 			=> 	"dropdown",
			// "heading" 		=> 	__( 'Click To Move', 'before' ),
			// "param_name" 	=> 	"onclick",
			// "description" 	=> 	__( 'Allow a user to click (or tap) anywhere on the image to move the slider to that location.', 'before' ),
			// "group" 		=> 	'Settings',
			// "value"			=>		array(
			// 	'True'			=>		'true',
			// 	'False'			=>		'false',
			// )
   //      ),
	),
) );