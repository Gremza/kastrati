<!-- Choose Option if style is Masonry for filterablegallery_wrap.php -->
<style>
	<?php if ($gridstyle == 'masonry') { ?>
		/*.maw_portfolioGallery_wrap<?php echo $randomPort_id; ?> {
			-webkit-column-count: <?php echo $columns; ?> !important;
		    -moz-column-count: <?php echo $columns; ?> !important;
		    column-count: <?php echo $columns; ?> !important;
		}
		@media screen and (max-width: 961px) {
		    .maw_portfolioGallery_wrap<?php echo $randomPort_id; ?> {
		        -webkit-column-count: <?php echo $columnstab; ?> !important;
		        -moz-column-count: <?php echo $columnstab; ?> !important;
		        column-count: <?php echo $columnstab; ?> !important;
		    }
		}

		@media screen and (max-width: 480px) {
		    .maw_portfolioGallery_wrap<?php echo $randomPort_id; ?> {
		        -webkit-column-count: <?php echo $columnsmbl; ?> !important;
		        -moz-column-count: <?php echo $columnsmbl; ?> !important;
		        column-count: <?php echo $columnsmbl; ?> !important;
		    }
		}*/
	<?php } ?>
</style>