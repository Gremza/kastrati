<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_whatsapp_wrap extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'style'					=>		'wa_btn_lightbox',
			'position'				=>		'wa_popup_container_right_ps',
			'right_ps'				=>		'27',
			'left_ps'				=>		'27',
			'bottom_ps'				=>		'27',
			'btn_info_text'			=>		'Need Help? Chat with us',
			'wa_popup_title'		=>		'Start a Conversation',
			'wa_popup_subtitle'		=>		'The team typically replies in a few minutes.',
			'pc_visible'			=>		'show',
			'mbl_visible'			=>		'show',
			'btnclr'				=>		'#fff',
			'btnbg'					=>		'#2db742',
			'btn_hover_clr'			=>		'#fff',
			'btn_hover_bg'			=>		'#249235',
			'popup_theme'			=>		'#2db742',
			'wa_info_clr'			=>		'#43474e',
			'wa_info_bg'			=>		'#f5f7f9',
			'popup_title_size'		=>		'',
			'wa_info_size'			=>		'',
			'classname'				=>		'',
			'call_visible'			=>		'show',
			'phone_numb'			=>		'+4412345678',
			'call_timing'			=>		'09:00 to 24:00 UTC+1',
		), $atts ) );
		$GLOBALS['global_whatsapp_style'] = $style;
		$some_id = rand(5, 500);
		$content = wpb_js_remove_wpautop($content, true);
		wp_enqueue_style( 'whatsappchat-css', plugins_url( '../css/whatsappchat.css' , __FILE__ ));
		wp_enqueue_script( 'whatsapps-chat-js', plugins_url( '../js/whatsapps.chat.js' , __FILE__ ));
		ob_start(); ?>

		<?php $hex = $btnbg; list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x"); ?>
		<?php $hexOn = $btn_hover_bg; list($R, $G, $B) = sscanf($hexOn, "#%02x%02x%02x"); ?>
		<div class="uae_whatsapp_wrap uae_whatsapp_wrap_<?php echo $some_id; ?> <?php echo $classname; ?>">
			
			<?php if ($style == "wa_btn_lightbox") { ?>
		        <div class="uae_whatsapp_chat_6 <?php echo $position ?> wa_pending wa_active wa_lauch">
		            <div class="wa_popup_heading" style="background: <?php echo $popup_theme; ?>;">
		                <div class="wa_popup_title" style="font-size: <?php echo $popup_title_size; ?>px;">
		                    <?php echo $wa_popup_title; ?>
		                </div>
		                <div class="wa_popup_intro">
		                    Hi! Click one of our members below to chat on <strong>WhatsApp ;)</strong>
		                </div>
		            </div>
		            <div class="wa_popup_content">
		                <div class="wa_popup_notice">
		                    <?php echo $wa_popup_subtitle; ?>
		                </div>
		                <?php echo $content; ?>
		                <?php if ($call_visible == "show") { ?>
			                <div class="qlwapp-footer">
								<p>Call us to <a href="tel://<?php echo $phone_numb; ?>"><?php echo $phone_numb; ?></a> <em><?php echo $call_timing; ?></em></p>
							</div>
						<?php } ?>
		        	</div>
		    	</div>
				
				<!-- Click Button For Open Popup -->
		    	<div class="uae-whatsapp-link-3 <?php echo $position ?>" data-active-status="false"
	            style="color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>;">
	            	<?php if ($btn_info_text != "") { ?>
		                <div class="wa_btn_tooltip_txt" style="font-size: <?php echo $wa_info_size; ?>px; color: <?php echo $wa_info_clr; ?>; background: <?php echo $wa_info_bg; ?>;">
		                    <?php echo $btn_info_text; ?>
		                </div>
		            <?php } ?>
	                <span style="position:relative;">
	                    <img class="uae_whatsapp_icon" src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp_logo.svg">
	                    <i class="uae_cross_icon fas fa-times" aria-hidden="true"></i>
	                </span>
	            </div>
			<?php } ?>

			<?php if ($style == "wa_btn_lightbox_2") { ?>
				<div class="uae_whatsapp_chat_5">
		           	<div class="wa_popup_wrap <?php echo $position ?>" data-wws-popup-status="1" style="display: block;">
		              <div class="wa_popup_body">
		                 <div class="wa_popup_support_wrap">
		                    <div class="wa_popup_support">
		                       <div class="wa_popup_support_about" style="font-size: <?php echo $popup_title_size; ?>px; background-color: <?php echo $popup_theme; ?>;">
		                          <?php echo $wa_popup_title; ?>                   
		                       </div>
		                    </div>
		                 </div>
		                 <div class="wa_clearfix"></div>
		                 <div class="wa_popup_support_team_container">
		                    <div class="wa_popup_support_person_wrap" style="display: block;">
		                		<?php echo $content; ?>
		                		<?php if ($call_visible == "show") { ?>
					                <div class="qlwapp-footer">
										<p>Call us: <a href="tel://<?php echo $phone_numb; ?>"> <?php echo $phone_numb; ?></a> <em><?php echo $call_timing; ?></em></p>
									</div>
								<?php } ?>
		                    </div>
		                 </div>
		              </div>
		           	</div>

		           <!-- Click Button For Open Popup -->
		           <div class="uae-whatsapp-link-3 <?php echo $position ?>" data-active-status="false"
		            style="color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>;">
		            	<?php if ($btn_info_text != "") { ?>
			                <div class="wa_btn_tooltip_txt" style="font-size: <?php echo $wa_info_size; ?>px; color: <?php echo $wa_info_clr; ?>; background: <?php echo $wa_info_bg; ?>;">
			                    <?php echo $btn_info_text; ?>
			                </div>
			            <?php } ?>
		                <span style="position:relative;">
		                    <img class="uae_whatsapp_icon" src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp_logo.svg">
		                    <i class="uae_cross_icon fas fa-times" aria-hidden="true"></i>
		                </span>
		            </div>
		        </div>
			<?php } ?>
		</div>

		 <style>
			<?php if ($style == 'wa_btn_lightbox') { ?>
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover {
					color: <?php echo $btn_hover_clr ?> !important;
					background: <?php echo $btn_hover_bg ?> !important;
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::before, 
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::after {
					<?php echo "border: 5px solid rgba($r, $g, $b, 0.5) !important;" ?>
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::before,  
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::after {
					<?php echo "border: 5px solid rgba($R, $G, $B, 0.5) !important;" ?>
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae_whatsapp_chat_6 .wa__stt {
				    border-left: 2px solid <?php echo $popup_theme ?>;
				}
			<?php }

			if ($style == 'wa_btn_lightbox_2') { ?>
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover {
					color: <?php echo $btn_hover_clr ?> !important;
					background: <?php echo $btn_hover_bg ?> !important;
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::before, 
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::after {
					<?php echo "border: 5px solid rgba($r, $g, $b, 0.5) !important;" ?>
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::before,  
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::after {
					<?php echo "border: 5px solid rgba($R, $G, $B, 0.5) !important;" ?>
				}
			<?php } ?>
			.uae_whatsapp_wrap_<?php echo $some_id; ?> .wa_popup_container_right_ps{
				right: <?php echo $right_ps ?>px !important;
				bottom: <?php echo $bottom_ps ?>px !important;
			}
			.uae_whatsapp_wrap_<?php echo $some_id; ?> .wa_popup_container_left_ps{
				left: <?php echo $left_ps ?>px !important;
				bottom: <?php echo $bottom_ps ?>px !important;
			}
			<?php if ($pc_visible == 'hide') { ?>
				@media only screen and (min-width: 767px) {
					.uae_whatsapp_wrap_<?php echo $some_id; ?>.uae_whatsapp_wrap {
						display: none;
					}
				}
			<?php }
			if ($mbl_visible == 'hide') { ?>
				@media only screen and (max-width: 767px) {
					.uae_whatsapp_wrap_<?php echo $some_id; ?>.uae_whatsapp_wrap {
						display: none;
					}
				}
			<?php } ?>
        </style>

		<?php return ob_get_clean();
	}
}


vc_map( array(
	"base" 			=> "whatsapp_wrap",
	"name" 			=> __( 'WhatsApp Multiple Chat', 'megaaddons' ),
	"as_parent" 	=> array('only' => 'whatsapp_son'),
	"content_element" => true,
	"js_view" 		=> 'VcColumnView',
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Get instant messages', 'megaaddons'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/whatsapp.png',
	'params' => array(
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Choose Style', 'megaaddons' ),
			"param_name" 	=> 	"style",
			"description" 	=> 	__( 'choose style <a href="https://addons.topdigitaltrends.net/whatsapp-chat-wordpress/">See demo</a>', 'megaaddons' ),
			"group" 		=> 'Settings',
			"value"			=> array(
				"Multiple Chat LightBox"	=>	"wa_btn_lightbox",
				"Multiple Chat LightBox 2"	=>	"wa_btn_lightbox_2",
			)
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Position', 'megaaddons' ),
			"param_name" 	=> 	"position",
			"group" 		=> 'Settings',
			"value"			=> array(
				"Right"			=>	"wa_popup_container_right_ps",
				"Left"			=>	"wa_popup_container_left_ps",
			)
		),

		array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Right Position', 'megaaddons' ),
			"param_name" 	=> 	"right_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => 'wa_popup_container_right_ps'),
			"group" 		=> 	'Settings',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Left Position', 'megaaddons' ),
			"param_name" 	=> 	"left_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => 'wa_popup_container_left_ps'),
			"group" 		=> 	'Settings',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Bottom Position', 'megaaddons' ),
			"param_name" 	=> 	"bottom_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => array('wa_popup_container_right_ps', 'wa_popup_container_left_ps')),
			"group" 		=> 	'Settings',
        ),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Info Text', 'megaaddons' ),
			"param_name" 	=> 	"btn_info_text",
			"dependency" 	=> array('element' => "style", 'value' => array('wa_btn_lightbox', 'wa_btn_lightbox_2')),
			"value" 		=> 	"Need Help? Chat with us",
			"group" 		=> 	'Settings',
        ),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Popup Title', 'megaaddons' ),
			"param_name" 	=> 	"wa_popup_title",
			"value" 		=> 	"Start a Conversation",
			"group" 		=> 	'Settings',
        ),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Popup Subtitle', 'megaaddons' ),
			"param_name" 	=> 	"wa_popup_subtitle",
			"dependency" => array('element' => "style", 'value' => 'wa_btn_lightbox'),
			"value" 		=> 	"The team typically replies in a few minutes.",
			"group" 		=> 	'Settings',
        ),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide on PC', 'megaaddons' ),
			"param_name" 	=> 	"pc_visible",
			"group" 		=> 'Settings',
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide on Mobile', 'megaaddons' ),
			"param_name" 	=> 	"mbl_visible",
			"group" 		=> 'Settings',
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Extra class name', 'megaaddons' ),
			"param_name" 	=> 	"classname",
			"description" 	=> 	"Style particular content element differently - add a class name and refer to it in custom CSS.",
			"group" 		=> 	'Settings',
        ),

		// =================== Phone Call Settings ====================== >>
		 
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Direct Phone Call', 'megaaddons' ),
			"param_name" 	=> 	"call_visible",
			"description" 	=> 	"It allows the user for making direct call to your number without whatsapp",
			"group" 		=> "Phone Call",
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Phone Number', 'megaaddons' ),
			"param_name" 	=> 	"phone_numb",
			"dependency" 	=> array('element' => "call_visible", 'value' => "show"),
			"value"			=>	"+4412345678",
			"group" 		=> 	"Phone Call",
        ),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Phone Call Timing', 'megaaddons' ),
			"param_name" 	=> 	"call_timing",
			"dependency" 	=> array('element' => "call_visible", 'value' => "show"),
			"value"			=>	"09:00 to 24:00 UTC+1",
			"group" 		=> 	"Phone Call",
        ),

		// =================== Text Typography ====================== >>
		
		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Theme Color', 'slider' ),
			"param_name" 	=> 	"popup_theme",
			"value" 		=> 	"rgb(45, 183, 66)",
			"group" 		=> 'Typography',
		),

		array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Popup Title [Font Size]', 'megaaddons' ),
			"param_name" 	=> 	"popup_title_size",
			"value" 		=> 	"Start a Conversation",
			"suffix" 		=> 	"px",
			"group" 		=> 	'Typography',
        ),

        array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_url",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Button Color Settings</span>', 'ihover' ),
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Text Color', 'slider' ),
			"param_name" 	=> 	"btnclr",
			"value" 		=> 	"#fff",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Button Background', 'slider' ),
			"param_name" 	=> 	"btnbg",
			"value" 		=> 	"#2db742",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Hover Color', 'slider' ),
			"param_name" 	=> 	"btn_hover_clr",
			"value" 		=> 	"#fff",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Hover Background', 'slider' ),
			"param_name" 	=> 	"btn_hover_bg",
			"value" 		=> 	"#249235",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_url",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Info Text Settings</span>', 'ihover' ),
			"group" 		=> 'Typography',
		),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Info Text [Font Size]', 'megaaddons' ),
			"param_name" 	=> 	"wa_info_size",
			"value" 		=> 	"Start a Conversation",
			"suffix" 		=> 	"px",
			"group" 		=> 	'Typography',
        ),

        array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Info Color', 'slider' ),
			"param_name" 	=> 	"wa_info_clr",
			"value" 		=> 	"#43474e",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Info Background', 'slider' ),
			"param_name" 	=> 	"wa_info_bg",
			"value" 		=> 	"#f5f7f9",
			"group" 		=> 'Typography',
		),
	)
) 
);
