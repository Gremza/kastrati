<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_whatsapp_chat_single extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'alignment'				=>		'left',
			'position'				=>		'wa_popup_container_right_ps',
			'right_ps'				=>		'27',
			'left_ps'				=>		'27',
			'bottom_ps'				=>		'27',
			'style'					=>		'default',
			'image_id'				=>		'',
			'btn_text'				=>		'Start a Conversation',
			'btn_tooltip_text'		=>		'Need Help? Chat with us',
			'btn_name'				=>		'Michael Scolfield',
			'status'				=>		'online',
			'status_text'			=>		'Online',
			'btn_prof'				=>		'Assistant Manager',
			'btn_phone_number'		=>		'',
			'btn_wa_text'			=>		'',
			'wa_desc_sc'			=>		'',
			// 'wa_popup_title'		=>		'Start a Conversation',
			// 'wa_popup_subtitle'	=>		'The team typically replies in a few minutes.',
			'btnclr'				=>		'#fff',
			'btnbg'					=>		'#2db742',
			'btn_hover_clr'			=>		'#fff',
			'btn_hover_bg'			=>		'#249235',
			'btn_padding_top_bottm'	=>		'',
			'btn_padding_right_left'=>		'',
			'btn_wa_width'			=>		'',
			'btn_radius'			=>		'',
			'pc_visible'			=>		'show',
			'mbl_visible'			=>		'show',
			'icon_size'				=>		'',
			'text_typography'		=>		'',
			'wa_tooltip_size'		=>		'',
			'classname'				=>		'',
		), $atts ) );
		$some_id = rand(5, 500);
		if ($image_id != '') {
			$image_url = wp_get_attachment_url( $image_id );		
		}
		$content = wpb_js_remove_wpautop($content, true);
		wp_enqueue_style( 'whatsappchat-single-css', plugins_url( '../css/whatsappchat.css' , __FILE__ ));
		wp_enqueue_script( 'whatsapps-chat-js', plugins_url( '../js/whatsapps.chat.js' , __FILE__ ));
		ob_start(); ?>

		<?php $hex = $btnbg; list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x"); ?>
		<?php $hexOn = $btn_hover_bg; list($R, $G, $B) = sscanf($hexOn, "#%02x%02x%02x"); ?>
		<div class="uae_whatsapp_wrap uae_whatsapp_wrap_<?php echo $some_id; ?> <?php echo $classname; ?>">
			<?php if ($style == "default") { ?>
				<div style="text-align: <?php echo $alignment; ?>;">
					<a class="uae-whatsapp-link-1 elementor-animation" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank"
					style="padding: <?php echo $btn_padding_top_bottm; ?>px <?php echo $btn_padding_right_left; ?>px; color: <?php echo $btnclr; ?>; background-color: <?php echo $btnbg; ?>; border-radius: <?php echo $btn_radius; ?>px; font-size: <?php echo $text_typography; ?>px;">
		                <span class="uae-whatsapp-text"><?php echo $btn_text; ?></span>
		                <i class="uae-whatsapp-icon fab fa-whatsapp" aria-hidden="true" style="margin-left: 5px; font-size: <?php echo $icon_size; ?>px;"></i>
		            </a>
		        </div>
			<?php } ?>

			<?php if ($style == "glow") { ?>
				<a class="uae-whatsapp-link-2 <?php echo $position ?>" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank"
	            style="width: <?php echo $btn_wa_width; ?>px; height: <?php echo $btn_wa_width; ?>px; color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>;">
		            <?php if ($btn_tooltip_text != "") { ?>
		                <div class="wa_btn_tooltip_txt" style="font-size: <?php echo $wa_tooltip_size; ?>px;">
		                    <?php echo $btn_tooltip_text; ?>
		                </div>
		            <?php } ?>
	                <span style="font-size: <?php echo $icon_size; ?>px;">
	                	<i class="uae-whatsapp-icon fab fa-whatsapp" aria-hidden="true"></i>
	                </span>
	            </a>
			<?php } ?>

			<?php if ($style == "animated") { ?>
				<a class="uae_wa_animated_btn <?php echo $position ?>" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank"
	            style=" background-image: url('<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp.gif');
	            width: <?php echo $btn_wa_width; ?>px; height: <?php echo $btn_wa_width; ?>px; border-radius: 50px; background-position: center;background-size: 114%; background-color: #4CAF50;"></a>
			<?php } ?>

			<?php if ($style == "btn_with_icon") { ?>
				<div style="text-align: <?php echo $alignment; ?>;">
		        	<a class="uae_wa_button uae_wa_online uae_wa_btn_icon <?php if ($status == "offline") { ?> wa__stt_offline <?php } ?>" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank"
		        	style="color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>; border-radius: <?php echo $btn_radius; ?>px;">
		                <div class="uae_btn_icon">
		                    <img src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp_logo.svg" alt="img">
		                </div>
		                <div class="uae_wa_btn_txt" style="">
		                    <div class="uae_wa_cs_info">
		                        <div class="uae_wa_cs_name">
		                            <?php echo $btn_name; ?>
		                        </div>
		                        <div class="uae_wa_cs_status">
		                            <?php echo $status; ?>
		                        </div>
		                    </div>
		                    <div class="uae_wa_btn_title" style="font-size: <?php echo $text_typography; ?>px;">
		                        <?php echo $btn_text; ?>
		                    </div>
		                </div>
		                <span class="image-overlay overlay-type-extern" style="display: none;">
		                    <span class="image-overlay-inside"></span>
		                </span>
		            </a>
		    	</div>
			<?php } ?>

			<?php if ($style == "btn_with_img") { ?>
				<div style="text-align: <?php echo $alignment; ?>;">
		        	<a class="uae_wa_button uae_wa_online wa_btn_w_img <?php if ($status == "offline") { ?> wa__stt_offline <?php } ?>" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank"
		        	style="color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>; border-radius: <?php echo $btn_radius; ?>px;">
		                <div class="wa_cs_img">
		                    <div class="wa_cs_img_wrap" style="background: url(<?php echo $image_url; ?>) center center no-repeat; background-size: cover;"></div>
		                </div>
		                <div class="uae_wa_btn_txt" style="padding: <?php echo $btn_padding_top_bottm; ?>px <?php echo $btn_padding_right_left; ?>px <?php echo $btn_padding_top_bottm; ?>px 108px;">
		                    <div class="uae_wa_cs_info">
		                        <div class="uae_wa_cs_name">
		                            <?php echo $btn_name; ?>
		                        </div>
		                        <div class="uae_wa_cs_status">
		                            <?php echo $status; ?>
		                        </div>
		                    </div>
		                    <div class="uae_wa_btn_title" style="font-size: <?php echo $text_typography; ?>px;">
		                        <?php echo $btn_text; ?>
		                    </div>
		                </div>
		                <span class="image-overlay overlay-type-extern" style="display: none;">
		                    <span class="image-overlay-inside"></span>
		                </span>
		            </a>
		        </div>
			<?php } ?>	

			<?php if ($style == "btn_with_Popup") { ?>
				<div class="uae_whatsapp_chat_4 <?php echo $position ?>" style="width: 360px;">
	              <div class="wa_close_btn" color="rgb(255, 255, 255)" role="button" tabindex="0"></div>
	              <div class="wa_header_sec">
	                 <div size="52" class="wa_user_img">
	                    <img src="<?php echo $image_url; ?>" alt="">
	                 </div>
	                 <div class="wa_header_info_sec">
	                    <div class="wa_header_name">
	                       <?php echo $btn_name; ?>
	                    </div>
	                    <div class="wa_header_info" style="font-size: <?php echo $wa_tooltip_size; ?>px;">
	                       <?php echo $btn_tooltip_text; ?>
	                    </div>
	                 </div>
	              </div>
	              <div class="wa_component_sec" pattern="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp.png">
	                 <div class="wa_msg_wrap">
	                    <div class="wa_msg_sec" style="opacity: 1;">
	                       <div class="wa_author_name">
	                          <?php echo $btn_name; ?>
	                       </div>
	                       <div class="wa_text_sec">
	                          <?php echo $wa_desc_sc ?>
	                       </div>
	                       <div class="wa_time_sc" id="wa_time_sc_<?php echo $some_id; ?>">

	                       </div>
	                        <script type="text/javascript">
	                            function LocalTime() {
	                            	var date = new Date();
	                            	var time = date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
	                            	document.getElementById('wa_time_sc_<?php echo $some_id; ?>').innerHTML = time;
	                            }
	                            LocalTime();
	                        </script>
	                    </div>
	                 </div>
	              </div>
	              <a role="button" href="https://web.whatsapp.com/send?phone=<?php echo $btn_phone_number; ?>&text=<?php echo $btn_wa_text; ?>" target="_blank" title="WhatsApp" class="wa_default_btn">
	                  <img src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp_logo.svg" style="width: 20px; height: 20px;">
	                  <span class="wa_btn_text" style="font-size: <?php echo $text_typography; ?>px;"><?php echo $btn_text; ?></span>
	              </a>
	           </div>

	           <div class="uae-whatsapp-link-3 <?php echo $position ?>" data-active-status="false"
		            style="color: <?php echo $btnclr; ?>; background: <?php echo $btnbg; ?>;">
	                <span style="position:relative;">
	                    <img class="uae_whatsapp_icon" src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/whatsapp_logo.svg">
	                    <i class="uae_cross_icon fas fa-times" aria-hidden="true"></i>
	                </span>
	            </div>
			<?php } ?>		
		</div>

		<style>
			<?php if ($style == 'default') { ?>
			.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-1:hover {
				color: <?php echo $btn_hover_clr ?> !important;
				background-color: <?php echo $btn_hover_bg ?> !important;
			}
			<?php }
			if ($style == 'btn_with_icon' || $style == "btn_with_img") { ?>
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae_wa_button:hover {
					color: <?php echo $btn_hover_clr ?> !important;
					background: <?php echo $btn_hover_bg ?> !important;
				}
			<?php }
			if ($style == 'glow') { ?>
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-2:hover {
					color: <?php echo $btn_hover_clr ?> !important;
					background-color: <?php echo $btn_hover_bg ?> !important;
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-2::before, 
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-2::after {
					<?php echo "border: 5px solid rgba($r, $g, $b, 0.5) !important;" ?>
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-2:hover::before,  
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-2:hover::after {
					<?php echo "border: 5px solid rgba($R, $G, $B, 0.5) !important;" ?>
				}
			<?php }
			if ($style == 'btn_with_Popup') { ?>
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover {
					color: <?php echo $btn_hover_clr ?> !important;
					background-color: <?php echo $btn_hover_bg ?> !important;
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::before, 
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3::after {
					<?php echo "border: 5px solid rgba($r, $g, $b, 0.5) !important;" ?>
				}
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::before,  
				.uae_whatsapp_wrap_<?php echo $some_id; ?> .uae-whatsapp-link-3:hover::after {
					<?php echo "border: 5px solid rgba($R, $G, $B, 0.5) !important;" ?>
				}
			<?php } ?>
			.uae_whatsapp_wrap_<?php echo $some_id; ?> .wa_popup_container_right_ps{
				right: <?php echo $right_ps ?>px !important;
				bottom: <?php echo $bottom_ps ?>px !important;
			}
			.uae_whatsapp_wrap_<?php echo $some_id; ?> .wa_popup_container_left_ps{
				left: <?php echo $left_ps ?>px !important;
				bottom: <?php echo $bottom_ps ?>px !important;
			}
			<?php if ($pc_visible == 'hide') { ?>
				@media only screen and (min-width: 767px) {
					.uae_whatsapp_wrap_<?php echo $some_id; ?> a {
						display: none;
					}
				}
			<?php }
			if ($mbl_visible == 'hide') { ?>
				@media only screen and (max-width: 767px) {
					.uae_whatsapp_wrap_<?php echo $some_id; ?> a {
						display: none;
					}
				}
			<?php } ?>
		</style>

		<?php return ob_get_clean();
	}
}


vc_map( array(
	"name" 			=> __( 'WhatsApp Single Chat', 'megaaddons' ),
	"base" 			=> "whatsapp_chat_single",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Get instant messages', 'megaaddons'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/whatsapp.png',
	'params' => array(
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Choose Style', 'megaaddons' ),
			"param_name" 	=> 	"style",
			"description" 	=> 	__( 'choose style <a href="https://addons.topdigitaltrends.net/whatsapp-chat-wordpress/">See demo</a>', 'megaaddons' ),
			"group" 		=> 'General',
			"value"			=> array(
				"Simple Button"			=>	"default",
				"Glow Button"			=>	"glow",
				"Animated Icon"			=>	"animated",
				"Button With Icon"		=>	"btn_with_icon",
				"Button With Image"		=>	"btn_with_img",
				"Button With Popup"		=>	"btn_with_Popup",
			)
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Button Align', 'megaaddons' ),
			"param_name" 	=> 	"alignment",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_img', 'btn_with_icon')),
			"group" 		=> 'General',
			"value"			=> array(
				"Left"			=>	"left",
				"Center"		=>	"center",
				"Right"			=>	"right",
			)
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Status', 'megaaddons' ),
			"param_name" 	=> 	"status",
			"dependency" 	=> array('element' => "style", 'value' => array('btn_with_icon', 'btn_with_img')),
			"group" 		=> 'General',
			"value"			=> array(
				"Online"	=>	"online",
				"Offline"	=>	"offline",
			)
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Online/Offline Text', 'megaaddons' ),
			"param_name" 	=> 	"status_text",
			"value"			=> 'Online',
			"dependency" 	=> array('element' => "style", 'value' => array('btn_with_icon', 'btn_with_img')),
			"group" 		=> 'General',
		),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Button Padding [Top Bottom]', 'megaaddons' ),
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"btn_padding_top_bottm",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_img')),
			"suffix" 		=> 	"px",
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Button Padding [Right Left]', 'megaaddons' ),
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"btn_padding_right_left",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_img')),
			"suffix" 		=> 	"px",
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Button Width/Height', 'megaaddons' ),
			"edit_field_class" => "vc_col-sm-6 wdo_items_to_show wdo_margin_bottom",
			"param_name" 	=> 	"btn_wa_width",
			"dependency" 	=> array('element' => "style", 'value' => array('glow', 'animated')),
			"suffix" 		=> 	"px",
			"group" 		=> 	'General',
        ),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Position', 'megaaddons' ),
			"param_name" 	=> 	"position",
			"dependency" 	=> array('element' => "style", 'value' => array('glow', 'animated', 'btn_with_Popup')),
			"group" 		=> 'General',
			"value"			=> array(
				"Right"			=>	"wa_popup_container_right_ps",
				"Left"			=>	"wa_popup_container_left_ps",
			)
		),

		array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Right Position', 'megaaddons' ),
			"param_name" 	=> 	"right_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => 'wa_popup_container_right_ps'),
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Left Position', 'megaaddons' ),
			"param_name" 	=> 	"left_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => 'wa_popup_container_left_ps'),
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Bottom Position', 'megaaddons' ),
			"param_name" 	=> 	"bottom_ps",
			"suffix" 		=> 	"px",
			"edit_field_class" => "vc_col-sm-6",
			"value"			=>	"27",
			"dependency" 	=> array('element' => "position", 'value' => array('wa_popup_container_right_ps', 'wa_popup_container_left_ps')),
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Border Radius', 'megaaddons' ),
			"param_name" 	=> 	"btn_radius",
			"suffix" 		=> 	"px",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_icon', 'btn_with_img')),
			"group" 		=> 	'General',
        ),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide on PC', 'megaaddons' ),
			"param_name" 	=> 	"pc_visible",
			"group" 		=> 'General',
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide on Mobile', 'megaaddons' ),
			"param_name" 	=> 	"mbl_visible",
			"group" 		=> 'General',
			"value"			=> array(
				"Show"			=>	"show",
				"Hide"			=>	"hide",
			)
		),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Extra class name', 'megaaddons' ),
			"param_name" 	=> 	"classname",
			"description" 	=> 	"Style particular content element differently - add a class name and refer to it in custom CSS.",
			"group" 		=> 	'General',
        ),

        // =================== Text Settings ====================== >>

		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Choose Image', 'megaaddons' ),
			"param_name" 	=> 	"image_id",
			"dependency" 	=> array('element' => "style", 'value' => array('btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Text',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Button Text', 'megaaddons' ),
			"param_name" 	=> 	"btn_text",
			"value"			=> 'Start a Conversation',
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Text',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Info Text', 'megaaddons' ),
			"param_name" 	=> 	"btn_tooltip_text",
			"value"			=> 'Need Help? Chat with us',
			"dependency" 	=> array('element' => "style", 'value' => array('glow', 'btn_with_Popup')),
			"group" 		=> 'Text',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Name', 'megaaddons' ),
			"param_name" 	=> 	"btn_name",
			"value"			=> 'Michael Scolfield',
			"dependency" 	=> array('element' => "style", 'value' => array('btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Text',
		),

		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'Section Text', 'megaaddons' ),
			"param_name" 	=> 	"wa_desc_sc",
			"dependency" 	=> array('element' => "style", 'value' => array('btn_with_Popup')),
			"value"			=> "I'm here to help, so let me know what's up and I'll be happy to find a solution",
			"group" 		=> 'Text',
		),

		// array(
		// 	"type" 			=> 	"textfield",
		// 	"heading" 		=> 	__( 'Professional', 'megaaddons' ),
		// 	"param_name" 	=> 	"btn_prof",
		// 	"value"			=> 'Assistant Manager',
		// 	"dependency" 	=> array('element' => "style", 'value' => array('btn_with_icon', 'btn_with_img')),
		// 	"group" 		=> 'Text',
		// ),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'WhatsApp Phone Number', 'megaaddons' ),
			"param_name" 	=> 	"btn_phone_number",
			"value"			=> '+50235473364',
			"group" 		=> 'Text',
		),

		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'WhatsApp Text', 'megaaddons' ),
			"param_name" 	=> 	"btn_wa_text",
			"value"			=> 'Hello, I have visit Shortcode and I need help from you. Here is link https://elementor.topdigitaltrends.net',
			"group" 		=> 'Text',
		),


   //      array(
   //          "type" 			=> 	"textfield",
			// "heading" 		=> 	__( 'Popup Title', 'megaaddons' ),
			// "param_name" 	=> 	"wa_popup_title",
			// "dependency" => array('element' => "style", 'value' => 'wa_btn_lightbox'),
			// "value" 		=> 	"Start a Conversation",
			// "group" 		=> 	'Text',
   //      ),

   //      array(
   //          "type" 			=> 	"textfield",
			// "heading" 		=> 	__( 'Popup Subtitle', 'megaaddons' ),
			// "param_name" 	=> 	"wa_popup_subtitle",
			// "dependency" => array('element' => "style", 'value' => 'wa_btn_lightbox'),
			// "value" 		=> 	"The team typically replies in a few minutes.",
			// "group" 		=> 	'Text',
   //      ),

		// =================== Color Settings ====================== >>
		 
		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Text Color', 'slider' ),
			"param_name" 	=> 	"btnclr",
			"value" 		=> 	"#fff",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'glow', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Color',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Button Background', 'slider' ),
			"param_name" 	=> 	"btnbg",
			"value" 		=> 	"#2db742",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'glow', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Color',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Hover Color', 'slider' ),
			"param_name" 	=> 	"btn_hover_clr",
			"value" 		=> 	"#fff",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'glow', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Color',
		),

		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Hover Background', 'slider' ),
			"param_name" 	=> 	"btn_hover_bg",
			"value" 		=> 	"#249235",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'glow', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Color',
		),

		// =================== Typography Settings ====================== >>
		
		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Icon Size', 'megaaddons' ),
			"param_name" 	=> 	"icon_size",
			"suffix" 		=> 	"px",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'glow')),
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Text Size', 'megaaddons' ),
			"param_name" 	=> 	"text_typography",
			"suffix" 		=> 	"px",
			"dependency" 	=> array('element' => "style", 'value' => array('default', 'btn_with_icon', 'btn_with_img', 'btn_with_Popup')),
			"group" 		=> 'Typography',
		),

		array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Info [Font Size]', 'megaaddons' ),
			"param_name" 	=> 	"wa_tooltip_size",
			"value" 		=> 	"Start a Conversation",
			"suffix" 		=> 	"px",
			"dependency" 	=> array('element' => "style", 'value' => array('glow', 'btn_with_Popup')),
			"group" 		=> 	'Typography',
        ),
	)
) 
);
