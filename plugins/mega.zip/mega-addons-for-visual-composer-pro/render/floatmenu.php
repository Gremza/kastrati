<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_floating_menu_son extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'icon'				=>		'fa fa-home',
			'textvisibility'	=>		'maw_title_null',
			'stickytext'		=>		'',
			'textsize'			=>		'',
			'scrollto'			=>		'',
			'menubg'			=>		'#FF6E01',
			'checked'			=>		'',
			'tooltiptext'		=>		'',
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true);
		ob_start();

		?>
				    	
    	<li class="maw_floatmenu_li <?php echo $textvisibility; ?>">
			<a href="<?php echo $scrollto; ?>" style="background: <?php echo $menubg; ?>;">
				<span class="maw_floatmenu_icon">
					<i class="<?php echo $icon; ?>" aria-hidden="true" style="font-size: <?php echo $textsize ?>px;"></i>
				</span>
				<?php if ($textvisibility == "maw_title_null") { ?>
					<span class="maw_floatmenu_text" style="font-size: <?php echo $textsize ?>px;">
						<?php echo $stickytext; ?>
					</span>
				<?php } ?>

				<?php if (!empty($checked)) { ?>
	                <span class="tooltip maw_floatmenu_tooltip fas fa-info">
	                    <?php echo $tooltiptext; ?>
	                </span>
	            <?php } ?>
			</a>
		</li>
			

		<?php return ob_get_clean();
	}
}


vc_map( array(
	"base" 			=> "floating_menu_son",
	"name" 			=> __( 'Float Menu Settings', 'megaaddons' ),
	"as_child" 		=> array('only' => 'floating_menu_wrap'),
	"content_element" => true,
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('One page navigator sticky menu', 'megaaddons'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/floatmenu.png',
	'params' => array(
		array(
            "type" 			=> 	"iconpicker",
			"heading" 		=> 	__( 'Icon', 'megaaddons' ),
			"param_name" 	=> 	"icon",
			"description" 	=> 	__( 'Select icon', 'megaaddons' ),
			"value" 		=> 	'fa fa-home',
			"group" 		=> 	'General',
        ),

        array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Show/Hide Text', 'megaaddons' ),
			"param_name" 	=> 	"textvisibility",
			"group" 		=> 'General',
			"value"			=> array(
				"Show"			=>	"maw_title_null",
				"Hide"			=>	"maw_title_hide",
			)
		),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Floating Text', 'megaaddons' ),
			"param_name" 	=> 	"stickytext",
			"description" 	=> 	__( 'sticky menu text', 'megaaddons' ),
			"dependency" => array('element' => "textvisibility", 'value' => 'maw_title_null'),
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"vc_number",
			"heading" 		=> 	__( 'Text Font Size', 'megaaddons' ),
			"param_name" 	=> 	"textsize",
			"dependency" => array('element' => "textvisibility", 'value' => 'maw_title_null'),
			"suffix" 		=> 	"px",
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Scroll To', 'megaaddons' ),
			"param_name" 	=> 	"scrollto",
			"description" 	=> 	__( 'eg: "#id" or ".class".', 'megaaddons' ),
			"group" 		=> 	'General',
        ),

        array(
            "type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Menu Background', 'megaaddons' ),
			"param_name" 	=> 	"menubg",
			"description" 	=> 	__( 'Select icon', 'megaaddons' ),
			"value" 		=> 	'#FF6E01',
			"group" 		=> 	'General',
        ),

        array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Tooltip onHover', 'megaaddons' ),
			"param_name" 	=> 	"checked",
			"value" 		=> 	'true',
			"group" 		=> 	'Settings',
		),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Tooltip Text', 'megaaddons' ),
			"param_name" 	=> 	"tooltiptext",
			"dependency" => array('element' => "checked", 'value' => 'true'),
			"group" 		=> 	'Settings',
        ),
	),
) );
