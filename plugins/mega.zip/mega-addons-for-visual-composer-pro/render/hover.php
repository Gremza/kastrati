<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_mvc_ihe extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'image_align' 		=>		'left',
			'classname' 		=>		'',
			'image_id' 			=>		'',
			'alt'	 			=>		'',
			'height' 			=>		'',
			'width' 			=>		'',
			'popup' 			=>		'disable',
			'caption_bg' 		=>		'',
			'title_clr'	 		=>		'',
			'title_bg'	 		=>		'none',
			'desc_clr'	 		=>		'',
			'caption_in_popup' 	=>		'caption',
			'caption_url' 		=>		'',
			'caption_url_target'=>		'',
			'modal_width' 		=>		'',
			'modal_height' 		=>		'',
			'caption_text' 		=>		'',
			'tag' 				=>		'h3',
			'effect' 			=>		'false',
			'border_width' 		=>		'5',
			'border_style' 		=>		'solid',
			'border_color' 		=>		'#fff',
			'hover_effect' 		=>		'ihe-fade square effect6 from_top_and_bottom',
			'title_size' 		=>		'',
			'title_line_h' 		=>		'',
			'title_margin' 		=>		'',
			'title_style' 		=>		'',
			'text_decoration' 	=>		'',
			'desc_size' 		=>		'',
			'use_theme_fonts' =>		'',
			'google_fonts' 	=>		'default',
		), $atts ) );
		$some_id = rand(5, 500);
		$caption_url = vc_build_link($caption_url);
		if ($image_id != '') {
			$image_url = wp_get_attachment_url( $image_id );		
		}
		wp_enqueue_style( 'fancybox-css', plugins_url( '../css/jquery.fancybox.min.css' , __FILE__ ));
		wp_enqueue_script( 'fancybox-js', plugins_url( '../js/jquery.fancybox.min.js' , __FILE__ ), array('jquery'));
		wp_enqueue_script( 'custom-pretty-js', plugins_url( '../js/customPrettyPhoto.js' , __FILE__ ), array('jquery'));
		$content = wpb_js_remove_wpautop($content, true);
		$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
		$googleallfonts = "";
		if($google_fonts != "default"){
			$fontsData = $this->getFontsData( $atts, 'google_fonts' );
			$googleFontsStyles = $this->googleFontsStyles( $fontsData );
			$this->enqueueGoogleFonts( $fontsData );
			if (empty($googleFontsStyles) == false){
				$googleallfonts = esc_attr( implode( ';', $googleFontsStyles ) );
			} else {
				$googleallfonts = $googleFontsStyles;
			}
		}
		ob_start(); ?>

			<?php $hex = $caption_bg; list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x"); ?>
			<div class="maw_ihover_wrapper" style="text-align: <?php echo $image_align ?>;">
				<?php if ( !in_array($hover_effect, ['square ihe_blog_style', 'ihe_style1', 'ihe_style3', 'ihe_style4', 'ihe_style5', 'ihe_style6', 'ihe_style7'], true ) ) { ?>
					<div class="ih-item fancybox <?php echo $hover_effect; ?> ihover_<?php echo $some_id ?> ih_item_padding <?php echo $classname ?>"
						style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>; height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; display: inline-block;">
						<?php if (isset($caption_url['url']) && $caption_url['url'] != '') { ?>
							<a class="ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-slide="<?php echo $effect; ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
						<?php } ?>
						<?php if (isset($caption_url['url']) && $caption_url['url'] == NULL) { ?> <a> <?php } ?>
					      <div class="img">
						    <span style="box-shadow: inset 0 0 0 <?php echo $border_width; ?>px <?php echo $border_color; ?>, 0 1px 2px rgba(0, 0, 0, .3); opacity: 0.6;"></span>
						    <img src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
						  </div>
					      <div class="info" style="background-color: <?php echo $caption_bg; ?>;">
						    <div style="display:table;width:100%;height:100%;">
					    		<div style="display: table-cell !important;vertical-align: middle !important;">
					    			<<?php echo $tag; ?> class="ihe_title" style="background: <?php echo $title_bg; ?>;">
					    				<?php echo $caption_text; ?>
					    			</<?php echo $tag; ?>>
					      			<span class="ihe_description">
					      				<?php echo $content; ?>
					      			</span>
					      		</div>
					      	</div>
					      </div>
					    </a>
					</div>
				<?php } ?>

				<?php if ($hover_effect == 'ihe_style1') { ?>
					<div class="ihe_style1 ihover_<?php echo $some_id ?> <?php echo $classname ?>" style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>; width: <?php echo $width; ?>px; max-width: 100%; display: inline-block;">
						<a class="ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="images" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
							<div class="ihe_img_wrapper">
								<img src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
								<div class="ihe_desc_wrap">
									<<?php echo $tag; ?> class="ihe_title"><?php echo $caption_text; ?></<?php echo $tag; ?>>
									<div class="ihe_description">
					      				<?php echo $content; ?>
					      			</div>
								</div>
							</div>
						</a>
					</div>
				<?php } ?>


				<?php if ($hover_effect == 'square ihe_blog_style') { ?>
					<div class="ih-item fancybox <?php echo $hover_effect; ?> ihover_<?php echo $some_id ?> <?php echo $classname ?>"
						style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>; height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; display: inline-block;">
						<?php if (isset($caption_url['url']) && $caption_url['url'] != '') { ?>
							<a class="ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-slide="<?php echo $effect; ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
						<?php } ?>
						<?php if (isset($caption_url['url']) && $caption_url['url'] == NULL) { ?> <a> <?php } ?>
					      <div class="img">
						    <span style="box-shadow: inset 0 0 0 <?php echo $border_width; ?>px <?php echo $border_color; ?>, 0 1px 2px rgba(0, 0, 0, .3); opacity: 0.6;"></span>
						    <img src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
						  </div>
					      <div class="info" style="<?php echo "background-color: rgba($r, $g, $b, 0.7) !important;" ?>">
						    <div style="display:table;width:100%;height:100%;">
					    		<div style="display: table-cell !important;vertical-align: middle !important;">
					    			<h3 class="ihe_title" style="background: #1e1c1c;">
					    				<?php echo $caption_text; ?>
					    			</h3>
					      			<p class="ihe_description" style="background: <?php echo $caption_bg; ?>;">
					      				<?php echo wp_strip_all_tags ($content); ?>
					      			</p>
					      		</div>
					      	</div>
					      </div>
					    </a>
					</div>
				<?php } ?>


				<?php if ($hover_effect == 'ihe_style3') { ?>
					<div class="ihe_style3 ihover_<?php echo $some_id ?> <?php echo $classname ?>">
						<a class="ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
							<div class="photo_wrapper">
								<img class="scale-with-grid" src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
							</div>
							<div class="desc_wrapper" style="background: <?php echo $caption_bg; ?>;">
								<<?php echo $tag; ?> class="ihe_title">
									<?php echo $caption_text; ?>
								</<?php echo $tag; ?>>
							</div>
						</a>
					</div>
				<?php } ?>

				<?php if ($hover_effect == 'ihe_style4') { ?>
					<div class="ihe_style4 ihover_<?php echo $some_id ?> <?php echo $classname ?>" style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>;">
						<a class="ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
							<img class="scale-with-grid" src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
							<div class="desc">
								<div class="subtitle ihe_title" style="background: <?php echo $caption_bg; ?>;">
									<?php echo $caption_text; ?>
								</div>
								<div class="ihe_description"><?php echo $content; ?></div>
								<div class="line"></div>
							</div>
						</a>
					</div>
				<?php } ?>
				
				<?php if ($hover_effect == 'ihe_style5') { ?>
					<a class="ihover_<?php echo $some_id ?> ihe-fancybox ihe_style5 <?php echo $classname ?>" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
						<div class="box-badge" style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>;">
							<div class="box-image">
								<img src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
							</div>
							<div class="box-text" style="<?php echo "background-color: rgba($r, $g, $b, .85);" ?>">
								<div class="box-text-inner">
									<<?php echo $tag; ?> class="header-title ihe_title" style="color: #fff;"><?php echo $caption_text; ?></<?php echo $tag; ?>>
									<span class="ihe_description"><?php echo $content; ?></span>
								</div>
							</div>
						</div> 
					</a>
				<?php } ?>

				<?php if ($hover_effect == 'ihe_style6') { ?>
					<div class="ihe_style6 ihover_<?php echo $some_id ?> <?php echo $classname ?>" style="width: <?php echo $width; ?>px; max-width: 100%; display: inline-block;">
						<a class="image-boxes-link ihe-fancybox" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
								?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
							<div class="image-boxes-img-wrapper">
								<img src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;" class="image-boxes-img ">
							</div>
							<span class="imgboxes-border-helper"></span>
							<<?php echo $tag; ?> class="image-boxes-title ihe_title">
								<span><?php echo $caption_text; ?></span>
							</<?php echo $tag; ?>>
						</a>
						<div class="image-boxes-text ihe_description">
							<p><?php echo $content; ?></p>
						</div>
					</div>
				<?php } ?>


				<?php if ($hover_effect == 'ihe_style7') { ?>
					<div style="display: inline-block;">
						<div class="ihe_style7 portfolio-item ihover_<?php echo $some_id ?> <?php echo $classname ?>" style="border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_color; ?>;">
							<div class="post-featured">
								<div class="wbc-image-wrap">
									<a href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>" style="display: flex;">
										<img class="" src="<?php echo $image_url; ?>" alt="<?php echo $alt; ?>" style="height: <?php echo $height; ?>px; width: <?php echo $width; ?>px; max-width: 100%;">
									</a>
									<a class="item-link-overlay" href="" style="opacity: 0;"></a>
									<div class="wbc-extra-links" style="top: -100%;">
										<<?php echo $tag; ?> class="item-title ihe_title" style="color: #fff;">
											<?php echo $caption_text; ?>
										</<?php echo $tag; ?>>
										<div class="wbc-link-content">
											<a class="wbc-photo-up ihe-fancybox" href="<?php echo $image_url; ?>" data-width="<?php echo $modal_width; ?>" data-height="<?php echo $modal_height; ?>" <?php if ($popup == 'images') {?> data-fancybox="<?php echo $popup ?>" <?php }elseif ($popup == 'image') {
											?> data-fancybox <?php } ?> data-<?php echo $caption_in_popup; ?>="<?php echo wp_strip_all_tags ($content); ?>">
												<i class="fa fa-search"></i>
											</a>
											<a class="wbc-go-link" href="<?php echo esc_url($caption_url['url']); ?>" target="<?php echo $caption_url['target']; ?>" title="<?php echo esc_html($caption_url['title']); ?>">
												<i class="fa fa-link"></i>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>

			<style>
				.ihover_<?php echo $some_id ?>.ih-item.square.effect6.ihe-fade .info {
					<?php echo "background-color: rgba($r, $g, $b, 0.7) !important;" ?>
				}

				<?php if ($hover_effect == 'ihe_style5' || $hover_effect == 'ihe_style7') { ?>
					.ihover_<?php echo $some_id ?> .box-badge:hover .box-text,
					.ihover_<?php echo $some_id ?>.ihe_style7 .item-link-overlay {
						background-color: <?php echo $caption_bg; ?> !important;
					}
				<?php } ?>
				
				<?php if ($hover_effect == 'ihe_style3' || $hover_effect == 'ihe_style6') { ?>
					.ihe_style3.ihover_<?php echo $some_id ?> .desc_wrapper:after,
					.ihe_style6.ihover_<?php echo $some_id ?> .imgboxes-border-helper {
						border-bottom-color: <?php echo $caption_bg; ?> !important;
					}
				<?php } ?>

				.ihover_<?php echo $some_id ?> .ihe_title {
					color: <?php echo $title_clr; ?> !important;
					font-size: <?php echo $title_size; ?>px !important;
					font-style: <?php echo $title_style; ?>;
					text-decoration: <?php echo $text_decoration; ?>;
					line-height: <?php echo $title_line_h; ?>;
					margin-bottom: <?php echo $title_margin; ?>px !important;
					<?php echo $googleallfonts; ?>;
				}

				.ihover_<?php echo $some_id ?> .ihe_description,
				.ihover_<?php echo $some_id ?> .ihe_description * {
					color: <?php echo $desc_clr ?> !important;
					font-size: <?php echo $desc_size; ?>px !important;
					<?php echo $googleallfonts; ?>;
				}
			</style>
		<?php
		return ob_get_clean();
	}

	protected function getFontsData( $atts, $paramName ) {
		$googleFontsParam = new Vc_Google_Fonts();
		$field = WPBMap::getParam( $this->shortcode, $paramName );
		$fieldSettings = isset( $field['settings'], $field['settings']['fields'] ) ? $field['settings']['fields'] : array();
		$fontsData = strlen( $atts[ $paramName ] ) > 0 ? $googleFontsParam->_vc_google_fonts_parse_attributes( $fieldSettings, $atts[ $paramName ] ) : '';

		return $fontsData;
	}

	protected function googleFontsStyles( $fontsData ) {
		// Inline styles
		$fontFamily = explode( ':', $fontsData['values']['font_family'] );
		$styles[] = 'font-family:' . $fontFamily[0];
		$fontStyles = explode( ':', $fontsData['values']['font_style'] );
		if(count($fontStyles)>1){
			$styles[] = 'font-weight:' . $fontStyles[1];
			$styles[] = 'font-style:' . $fontStyles[2];
			return $styles;
		} else {
			return "";
		}

	}

	protected function enqueueGoogleFonts( $fontsData ) {
		// Get extra subsets for settings (latin/cyrillic/etc)
		$settings = get_option( 'wpb_js_google_fonts_subsets' );
		if ( is_array( $settings ) && ! empty( $settings ) ) {
			$subsets = '&subset=' . implode( ',', $settings );
		} else {
			$subsets = '';
		}

		// We also need to enqueue font from googleapis
		if ( isset( $fontsData['values']['font_family'] ) ) {
			wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $fontsData['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $fontsData['values']['font_family'] . $subsets );
		}
	}
}


vc_map( array(
	"name" 			=> __( 'Image Hover Effects', 'ihover' ),
	"base" 			=> "mvc_ihe",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Image Hover Effects', 'ihover'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/ihe.png',
	'params' => array(
		
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Hover Effect', 'ihover' ),
			"param_name" 	=> "hover_effect",
			"description" 	=> __( 'Choose hover effect <a href="http://gudh.github.io/ihover/dist/">See demo</a>', 'ihover' ),
			"group" 		=> 'Image',
			"value" 		=>  array(
				'Fade Effect'						=>		'ihe-fade square effect6 from_top_and_bottom',
				'Fade Effect 2'						=>		'ihe_style1',
				'Blog Style'      					=>      'square ihe_blog_style',
				'Image Bottom Text'      			=>      'ihe_style3',
				'Text Inside Image'      			=>      'ihe_style4',
				'Box Text'      					=>      'ihe_style5',
				'Box Underline'      				=>      'ihe_style6',
				'Portfolio Style'      				=>      'ihe_style7',
				'circle effect2 left to right'      =>      'circle effect2 left_to_right',
				'circle effect2 right to left'      =>      'circle effect2 right_to_left',
				'circle effect2 top to bottom'      =>      'circle effect2 top_to_bottom',
				'circle effect2 bottom to top'      =>      'circle effect2 bottom_to_top',
				'circle effect3 left to right'      =>      'circle effect3 left_to_right',
				'circle effect3 right to left'      =>      'circle effect3 right_to_left',
				'circle effect3 bottom to top'      =>      'circle effect3 bottom_to_top',
				'circle effect3 top to bottom'      =>      'circle effect3 top_to_bottom',
				'circle effect4 left to right'      =>      'circle effect4 left_to_right',
				'circle effect4 right to left'      =>      'circle effect4 right_to_left',
				'circle effect4 top to bottom'      =>      'circle effect4 top_to_bottom',
				'circle effect4 bottom to top'      =>      'circle effect4 bottom_to_top',
				'circle effect5'      				=>      'circle effect5',
				'circle effect6 scale up'      		=>      'circle effect6 scale_up',
				'circle effect6 scale down'      	=>      'circle effect6 scale_down',
				'circle effect6 scale down up'      =>      'circle effect6 scale_down_up',
				'circle effect7 left to right'      =>      'circle effect7 left_to_right',
				'circle effect7 right to left'      =>      'circle effect7 right_to_left',
				'circle effect7 top to bottom'      =>      'circle effect7 top_to_bottom',
				'circle effect7 bottom to top'      =>      'circle effect7 bottom_to_top',
				'circle effect8 left to right'      =>      'circle effect8 left_to_right',
				'circle effect8 right to left'      =>      'circle effect8 right_to_left',
				'circle effect8 top to bottom'      =>      'circle effect8 top_to_bottom',
				'circle effect8 bottom to top'      =>      'circle effect8 bottom_to_top',
				'circle effect9 left to right'      =>      'circle effect9 left_to_right',
				'circle effect9 right to left'      =>      'circle effect9 right_to_left',
				'circle effect9 top to bottom'      =>      'circle effect9 top_to_bottom',
				'circle effect9 bottom to top'      =>      'circle effect9 bottom_to_top',
				'circle effect10 top to bottom'     =>      'circle effect10 top_to_bottom',
				'circle effect10 bottom to top'     =>      'circle effect10 bottom_to_top',
				'circle effect11 left to right'     =>      'circle effect11 left_to_right',
				'circle effect11 right to left'     =>      'circle effect11 right_to_left',
				'circle effect11 top to bottom'     =>      'circle effect11 top_to_bottom',
				'circle effect11 bottom to top'     =>      'circle effect11 bottom_to_top',
				'circle effect12 left to right'     =>      'circle effect12 left_to_right',
				'circle effect12 right to left'     =>      'circle effect12 right_to_left',
				'circle effect12 top to bottom'     =>      'circle effect12 top_to_bottom',
				'circle effect12 bottom to top'     =>      'circle effect12 bottom_to_top',
				'circle effect13 from left and right'  =>   'circle effect13 from_left_and_right',
				'circle effect13 top to bottom'     =>      'circle effect13 top_to_bottom',
				'circle effect13 bottom to top'     =>      'circle effect13 bottom_to_top',
				'circle effect14 left to right'     =>      'circle effect14 left_to_right',
				'circle effect14 right to left'     =>      'circle effect14 right_to_left',
				'circle effect14 top to bottom'     =>      'circle effect14 top_to_bottom',
				'circle effect14 bottom to top'     =>      'circle effect14 bottom_to_top',
				'circle effect15 left to right'     =>      'circle effect15 left_to_right',
				'circle effect16 left to right'     =>      'circle effect16 left_to_right',
				'circle effect16 right to left'     =>      'circle effect16 right_to_left',
				'circle effect17'      				=>      'circle effect17',
				'circle effect18 bottom to top'     =>      'circle effect18 bottom_to_top',
				'circle effect18 left to right'     =>      'circle effect18 left_to_right',
				'circle effect18 right to left'     =>      'circle effect18 right_to_left',
				'circle effect18 top to bottom'     =>      'circle effect18 top_to_bottom',
				'circle effect19'      				=>      'circle effect19',
				'circle effect20 top to bottom'     =>      'circle effect20 top_to_bottom',
				'circle effect20 bottom to top'     =>      'circle effect20 bottom_to_top',
				'square effect1 left and right'     =>      'square effect1 left_and_right',
				'square effect1 top to bottom'      =>      'square effect1 top_to_bottom',
				'square effect1 bottom to top'      =>      'square effect1 bottom_to_top',
				'square effect2'      				=>      'square effect2',
				'square effect3 bottom to top'      =>      'square effect3 bottom_to_top',
				'square effect3 top to bottom'      =>      'square effect3 top_to_bottom',
				'square effect4'      				=>      'square effect4',
				'square effect5 left to right'      =>      'square effect5 left_to_right',
				'square effect5 right to left'      =>      'square effect5 right_to_left',
				'square effect6 from top and bottom'=>      'square effect6 from_top_and_bottom',
				'square effect6 from left and right'=>      'square effect6 from_left_and_right',
				'square effect6 top to bottom'      =>      'square effect6 top_to_bottom',
				'square effect6 bottom to top'      =>      'square effect6 bottom_to_top',
				'square effect7'      				=>      'square effect7',
				'square effect8 scaleup'      		=>      'square effect8 scale_up',
				'square effect8 scaledown'      	=>      'square effect8 scale_down',
				'square effect9 bottom to top'      =>      'square effect9 bottom_to_top',
				'square effect9 left to right'      =>      'square effect9 left_to_right',
				'square effect9 right to left'      =>      'square effect9 right_to_left',
				'square effect9 top to bottom'      =>      'square effect9 top_to_bottom',
				'square effect10 left to right'     =>      'square effect10 left_to_right',
				'square effect10 right to left'     =>      'square effect10 right_to_left',
				'square effect10 top to bottom'     =>      'square effect10 top_to_bottom',
				'square effect10 bottom to top'     =>      'square effect10 bottom_to_top',
				'square effect11 left to right'     =>      'square effect11 left_to_right',
				'square effect11 right to left'     =>      'square effect11 right_to_left',
				'square effect11 top to bottom'     =>      'square effect11 top_to_bottom',
				'square effect11 bottom to top'     =>      'square effect11 bottom_to_top',
				'square effect12 left to right'     =>      'square effect12 left_to_right',
				'square effect12 right to left'     =>      'square effect12 right_to_left',
				'square effect12 top to bottom'     =>      'square effect12 top_to_bottom',
				'square effect12 bottom to top'     =>      'square effect12 bottom_to_top',
				'square effect13 left to right'     =>      'square effect13 left_to_right',
				'square effect13 right to left'     =>      'square effect13 right_to_left',
				'square effect13 top to bottom'     =>      'square effect13 top_to_bottom',
				'square effect13 bottom to top'     =>      'square effect13 bottom_to_top',
				'square effect14 left to right'     =>      'square effect14 left_to_right',
				'square effect14 right to left'     =>      'square effect14 right_to_left',
				'square effect14 top to bottom'     =>      'square effect14 top_to_bottom',
				'square effect14 bottom to top'     =>      'square effect14 bottom_to_top',
				'square effect15 left to right'     =>      'square effect15 left_to_right',
				'square effect15 right to left'     =>      'square effect15 right_to_left',
				'square effect15 top to bottom'     =>      'square effect15 top_to_bottom',
				'square effect15 bottom to top'     =>      'square effect15 bottom_to_top',
			)
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Image Align', 'ihover' ),
			"param_name" 	=> "image_align",
			"group" 		=> 'Image',
			"value" 		=> array(
				'Left'			=>	'left',
				'Center'		=>	'center',
				'Right'			=>	'right',
			)
		),

		array(
            "type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Image', 'ihover' ),
			"param_name" 	=> 	"image_id",
			"description" 	=> 	__( 'Select the image', 'ihover' ),
			"group" 		=> 	'Image',
        ),

        array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Alternate Text', 'info-banner-vc' ),
			"param_name" 	=> 	"alt",
			"description" 	=> 	__( 'It will be used as alt attribute of img tag', 'info-banner-vc' ),
			"group" 		=> 	'Image',
        ),

        array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Image Width', 'ich-vc' ),
			"param_name" 	=> "width",
			"edit_field_class" => "vc_col-sm-6",
			"description" 	=> __( 'set in pixel e.g 250 or leave blank for default', 'ich-vc' ),
			"max"			=>	"",
			"suffix" 		=> 'px',
			"group" 		=> 'Image',
		),

	    array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Image Height', 'ich-vc' ),
			"param_name" 	=> "height",
			"edit_field_class" => "vc_col-sm-6",
			"description" 	=> __( 'set in pixel e.g 250 or leave blank for default', 'ich-vc' ),
			"max"			=>	"",
			"suffix" 		=> 'px',
			"group" 		=> 'Image',
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Lightbox', 'ihover' ),
			"param_name" 	=> "popup",
			"description" 	=> __( 'popup on click. paste image or video url in "Link To" field for opening popup on click', 'ihover' ),
			"group" 		=> 'Image',
			"value" 		=> array(
				'Disable'				=>	'disable',
				'LightBox'				=>	'image',
				'LightBox SlideShow'	=>	'images',
			)
		),

		array(
			"type" 			=> "vc_link",
			"heading" 		=> __( 'Link To', 'ihover' ),
			"param_name" 	=> "caption_url",
			"description" 	=> __( 'Enter URL to link caption', 'ihover' ),
			"group" 		=> 'Image',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Lightbox Width', 'ich-vc' ),
			"param_name" 	=> "modal_width",
			"edit_field_class" => "vc_col-sm-6",
			"description" 	=> __( 'width of Image/Video In lightbox or leave blank for default.', 'ich-vc' ),
			"dependency" => array('element' => "popup", 'value' => array('image', 'images')),
			"max"			=>	"",
			"suffix" 		=> 'px',
			"group" 		=> 'Image',
		),

	    array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Lightbox Height', 'ich-vc' ),
			"param_name" 	=> "modal_height",
			"edit_field_class" => "vc_col-sm-6",
			"description" 	=> __( 'Height of Image/Video In lightbox or leave blank for default.', 'ich-vc' ),
			"dependency" => array('element' => "popup", 'value' => array('image', 'images')),
			"max"			=>	"",
			"suffix" 		=> 'px',
			"group" 		=> 'Image',
		),

		array(
            "type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Extra class name', 'megaaddons' ),
			"param_name" 	=> 	"classname",
			"description" 	=> 	"Style particular content element differently - add a class name and refer to it in custom CSS.",
			"group" 		=> 	'Image',
        ),

		// array(
		// 	"type" 			=> "dropdown",
		// 	"heading" 		=> __( 'SlideShow Effect', 'ihover' ),
		// 	"param_name" 	=> "effect",
		// 	"dependency" => array('element' => "popup", 'value' => 'images'),
		// 	"group" 		=> 'URL',
		// 	"value" 		=> array(
		// 		'Default'			=>	'false',
		// 		'Slide'				=>	'slide',
		// 		'Fade'				=>	'fade',
		// 		'Circular'			=>	'circular',
		// 		'Tube'				=>	'tube',
		// 		'Zoom In Out'		=>	'zoom-in-out',
		// 		'Rotate'			=>	'rotate',
		// 	)
		// ),


		/* Caption */

		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Caption Title', 'ihover' ),
			"param_name" 	=> "caption_text",
			"edit_field_class" => "vc_col-sm-8 edit_field_padding_top",
			"group" 		=> 'Caption',
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Tag', 'megaaddons' ),
			"param_name" 	=> "tag",
			"description" 	=> 'Default is H3',
			"edit_field_class" => "vc_col-sm-4 edit_field_padding_top",
			"group" 		=> 'Caption',
			"value" 		=> array(
				'H1'			=>	'h1',
				'H2'			=>	'h2',
				'H3'			=>	'h3',
				'H4'			=>	'h4',
				'H5'			=>	'h5',
				'p'				=>	'p',
				'span'			=>	'span',
			)
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Caption Text In Popup', 'megaaddons' ),
			"param_name" 	=> "caption_in_popup",
			"dependency" 	=> array('element' => "popup", 'value' => array('image', 'images')),
			"group" 		=> 'Caption',
			"value" 		=> array(
				'Show'			=>	'caption',
				'Hide'			=>	'hide',
			)
		),
		array(
			"type" 			=> "textarea_html",
			"heading" 		=> __( 'Description', 'ihover' ),
			"param_name" 	=> "content",
			"description" 	=> __( 'Provide Caption Here', 'ihover' ),
			"group" 		=> 'Caption',
			"value"			=> '<h2>Caption Text Here</h2>'
		),

		/* Border */

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urlsa",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Color Settings</span>', 'ihover' ),
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Title Color', 'ihover' ),
			"param_name" 	=> "title_clr",
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Title Background', 'ihover' ),
			"param_name" 	=> "title_bg",
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Description Color', 'ihover' ),
			"param_name" 	=> "desc_clr",
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Caption Background Color', 'ihover' ),
			"param_name" 	=> "caption_bg",
			"description" 	=> __( 'Background color for caption', 'ihover' ),
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_url",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Border Settings</span>', 'ihover' ),
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Border Width', 'ihover' ),
			"param_name" 	=> "border_width",
			"description" 	=> __( 'Width of border, eg: 15. Leaving blank will disable border', 'ihover' ),
			"value"			=>	"5",
			"suffix" 		=> 'px',
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Border Style', 'ich-vc' ),
			"param_name" 	=> "border_style",
			"group" 		=> 'Design',
			"value"			=>	array(
				"Solid"		=>		"solid",
				"Dotted"	=>		"dotted",
				"Ridge"		=>		"ridge",
				"Dashed"	=>		"dashed",
				"Double"	=>		"double",
				"Groove"	=>		"groove",
				"Inset"		=>		"inset",
			)
		),

		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Border Color', 'ihover' ),
			"param_name" 	=> "border_color",
			"description" 	=> __( 'Select the color for border', 'ihover' ),
			"group" 		=> 'Design',
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urltitsle",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Google Fonts Settings</span>', 'ihover' ),
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> 	"checkbox",
			"heading" 		=> 	__( 'Use theme default font family?', 'creativelink' ),
			"param_name" 	=> 	"use_theme_fonts",
			"description" 	=> 	__( 'Use font family from the theme.', 'creativelink' ),
			"group" 		=> 	'Typography',
			"value" 		=> array(
					"Yes"		=> "yes",
			)
		),

		array(
			'type' => 'google_fonts',
			'param_name' => 'google_fonts',
			'value' => 'default',
			'settings' => array(
				'fields' => array(
					'font_family_description' => __( 'Select font family.', 'js_composer' ),
					'font_style_description' => __( 'Select font styling.', 'js_composer' ),
				),
			),
			"group" 		=> 	'Typography',
			'weight' => 0,
			'dependency' => array(
				'element' => 'use_theme_fonts',
				'value_not_equal_to' => 'yes',
			),
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urltitle",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Title Settings</span>', 'ihover' ),
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Title [Font Size]', 'ihover' ),
			"param_name" 	=> "title_size",
			"edit_field_class" => "vc_col-sm-4",
			"suffix" 		=> 'px',
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'line Height', 'ihover' ),
			"param_name" 	=> "title_line_h",
			"edit_field_class" => "vc_col-sm-4",
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Margin Bottom', 'ihover' ),
			"param_name" 	=> "title_margin",
			"edit_field_class" => "vc_col-sm-4",
			"suffix" 		=> 'px',
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Style', 'button' ),
			"param_name" 	=> "title_style",
			"group" 		=> 'Typography',
			"value"			=>	array(
				"Default"		=>		"default",
				"Normal"		=>		"normal",
				"Italic"		=>		"italic",
				"Oblique"		=>		"oblique",
			)
		),

		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Decoration', 'button' ),
			"param_name" 	=> "text_decoration",
			"group" 		=> 'Typography',
			"value"			=>	array(
				"Default"		=>		"default",
				"Underline"		=>		"underline",
				"Overline"		=>		"overline",
				"Line Through"	=>		"line-through",
				"None"			=>		"none",
			)
		),

		array(
			"type" 			=> "vc_links",
			"param_name" 	=> "caption_urldesc",
			"class"			=>	"ult_param_heading",
			"description" 	=> __( '<span style="Background: #ddd;padding: 10px; display: block; color: #302f2f;font-weight:600;">Description Settings</span>', 'ihover' ),
			"group" 		=> 'Typography',
		),

		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Description [Font Size]', 'ihover' ),
			"param_name" 	=> "desc_size",
			"suffix" 		=> 'px',
			"group" 		=> 'Typography',
		),
	),
) );