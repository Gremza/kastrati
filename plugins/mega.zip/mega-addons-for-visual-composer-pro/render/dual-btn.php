<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_vc_dual_button extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'style'				=>		'default',
			'radius'			=>		'2',
			'align'				=>		'left',
			'border_width'		=>		'0',
			'border_clr'		=>		'',
			'border_style'		=>		'none',
			'height'			=>		'30',
			'width'				=>		'60',
			'size'				=>		'20',
			'icon'				=>		'',
			'btn_text'			=>		'',
			'url'				=>		'',
			'txt_clr'			=>		'',
			'bg_clr'			=>		'',
			'hvr_clr'			=>		'',
			'hvr_bg'			=>		'',
			'icon2'				=>		'',
			'btn_text2'			=>		'',
			'url2'				=>		'',
			'txt_clr2'			=>		'',
			'bg_clr2'			=>		'',
			'hvr_clr2'			=>		'',
			'hvr_bg2'			=>		'',
			'divider'			=>		'none',
			'div_icon'			=>		'',
			'divider_txt'		=>		'',
			'divider_clr'		=>		'',
			'divider_bg'		=>		'',
		), $atts ) );
		$url = vc_build_link($url);
		$url2 = vc_build_link($url2);
		$some_id = rand(5, 500);
		wp_enqueue_style( 'hvr-btn-css', plugins_url( '../css/dual-btn.css' , __FILE__ ));
		$content = wpb_js_remove_wpautop($content, true);
		ob_start(); ?>
		
    	<?php if ($style == 'default') { ?>
    		<div class="mega-dual-btn mega-dual-<?php echo $some_id; ?>" style="text-align: <?php echo $align; ?>;">
	          <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>" title="<?php echo esc_html($url['title']); ?>" style="padding: <?php echo $height/2 ?>px <?php echo $width/2 ?>px; border-radius: <?php echo $radius ?>px; border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_clr; ?>; font-size: <?php echo $size; ?>px; color: <?php echo $txt_clr; ?>; background-color: <?php echo $bg_clr; ?>;" class="mega_hvr_anim mega_dual_def">
	            <i class="fa <?php echo $icon; ?>">&nbsp; </i><?php echo $btn_text; ?>
	          </a>
	          <a href="<?php echo esc_url($url2['url']); ?>" target="<?php echo $url2['target']; ?>" title="<?php echo esc_html($url2['title']); ?>" style="padding: <?php echo $height/2 ?>px <?php echo $width/2 ?>px; border-radius: <?php echo $radius ?>px; border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_clr; ?>; font-size: <?php echo $size; ?>px; color: <?php echo $txt_clr2; ?>; background-color: <?php echo $bg_clr2; ?>;" class="mega_hvr_anim2 mega_dual_def2">
	          	<?php echo $btn_text2; ?>&nbsp; <i class="fa <?php echo $icon2; ?>"></i>
	          	<span class="mega-dual-divider" style="color: <?php echo $divider_clr; ?>; background: <?php echo $divider_bg; ?>; display: <?php echo $divider; ?>;">
	          		<p><?php echo $divider_txt; ?></p>
	          		<i class="fa <?php echo $div_icon; ?>"></i>
	          	</span>
	          </a>
	    	</div>
    	<?php } ?>

		<?php if ($style == 'animated') { ?>
			<div class="mega-dual-btn mega-dual-<?php echo $some_id; ?>" style="text-align: <?php echo $align; ?>;">
	          <a href="<?php echo esc_url($url['url']); ?>" target="<?php echo $url['target']; ?>" title="<?php echo esc_html($url['title']); ?>" style="padding: <?php echo $height/2 ?>px <?php echo $width/2 ?>px; border-radius: <?php echo $radius ?>px; border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_clr; ?>; font-size: <?php echo $size; ?>px; color: <?php echo $txt_clr; ?>; background-color: <?php echo $bg_clr; ?>;" class="mega_hvr_anim hover-bounce-to-left">
	            <span style="background: <?php echo $hvr_bg; ?>;"></span> 
	            <i class="fa <?php echo $icon; ?>">&nbsp; </i><?php echo $btn_text; ?>
	          </a>
	          <a href="<?php echo esc_url($url2['url']); ?>" target="<?php echo $url2['target']; ?>" title="<?php echo esc_html($url2['title']); ?>" style="padding: <?php echo $height/2 ?>px <?php echo $width/2 ?>px; border-radius: <?php echo $radius ?>px; border: <?php echo $border_width; ?>px <?php echo $border_style; ?> <?php echo $border_clr; ?>; font-size: <?php echo $size; ?>px; color: <?php echo $txt_clr2; ?>; background-color: <?php echo $bg_clr2; ?>;" class="mega_hvr_anim2 hover-bounce-to-right">
	          	<span class="mega-dual-hvr-bg" style="background: <?php echo $hvr_bg2; ?>;"></span>
	          	<?php echo $btn_text2; ?>&nbsp; <i class="fa <?php echo $icon2; ?>"></i>
	          	<span class="mega-dual-divider" style="color: <?php echo $divider_clr; ?>; background: <?php echo $divider_bg; ?>; display: <?php echo $divider; ?>;">
	          		<p><?php echo $divider_txt; ?></p>
	          		<i class="fa <?php echo $div_icon; ?>"></i>
	          	</span>
	          </a>
	    	</div>
    	<?php } ?>

    	<style>
			.mega-dual-<?php echo $some_id; ?> .mega_hvr_anim:hover{
				color: <?php echo $hvr_clr; ?> !important;
			}
			.mega-dual-<?php echo $some_id; ?> .mega_hvr_anim2:hover{
				color: <?php echo $hvr_clr2; ?> !important;
			}

			.mega-dual-<?php echo $some_id; ?> .mega_dual_def:hover{
				color: <?php echo $hvr_clr ?> !important;
				background-color: <?php echo $hvr_bg; ?> !important;
			}
			.mega-dual-<?php echo $some_id; ?> .mega_dual_def2:hover{
				color: <?php echo $hvr_clr2 ?> !important;
				background-color: <?php echo $hvr_bg2; ?> !important;
			}
    	</style>

		<?php
		return ob_get_clean();
	}
}


vc_map( array(
	"name" 			=> __( 'Dual Button', 'dual-btn' ),
	"base" 			=> "vc_dual_button",
	"category" 		=> __('Mega Addons'),
	"description" 	=> __('Add a dual button and give some custom design', 'dual-btn'),
	"icon" => plugin_dir_url( __FILE__ ).'../icons/dual-btn.png',
	'params' => array(
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Choose Style', 'dual-btn' ),
			"param_name" 	=> "style",
			"group" 		=> 'General',
			"description" 	=> __( 'button hover style <a href="https://addons.topdigitaltrends.net/dual-button/" target="_blank">See Demo</a>', 'dual-btn' ),
			"value" 		=> array(
				'Default' 				=>  'default',
				'Bounce Left & Right' 	=>  'animated',
			)
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Button Align', 'dual-btn' ),
			"param_name" 	=> "align",
			"group" 		=> 'General',
			"description" 	=> __( 'set button position', 'dual-btn' ),
			"value" 		=> array(
				'Left' 				=>  'left',
				'Center' 			=>  'center',
				'Right' 			=>  'right',
			)
		),
		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Border Radius', 'dual-btn' ),
			"param_name" 	=> "radius",
			"description" 	=> __( 'button border radius, set in pixel', 'dual-btn' ),
			"value"			=>	"2",
			"suffix" 		=> 'px',
			"group" 		=> 'General',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Border Width', 'dual-btn' ),
			"param_name" 	=> "border_width",
			"group" 		=> 'General',
			"value" 		=> array(
				'0' 				=>  '0',
				'1' 				=>  '1',
				'2' 				=>  '2',
				'3' 				=>  '3',
				'3' 				=>  '3',
				'4' 				=>  '4',
				'4' 				=>  '4',
				'5' 				=>  '5',
				'5' 				=>  '5',
				'6' 				=>  '6',
			)
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Border Color', 'dual-btn' ),
			"param_name" 	=> "border_clr",
			"description" 	=> __( 'button border radius, set in pixel', 'dual-btn' ),
			"value"			=>	"2px",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Border Style', 'dual-btn' ),
			"param_name" 	=> "border_style",
			"group" 		=> 'General',
			"value" 		=> array(
				"None"		=>		"none",
				"Solid"		=>		"solid",
				"Dotted"	=>		"dotted",
				"Riged"		=>		"riged",
				"Dashed"	=>		"dashed",
				"Double"	=>		"double",
				"Groove"	=>		"groove",
				"Inset"		=>		"inset",
			)
		),
		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Button Height', 'dual-btn' ),
			"param_name" 	=> "height",
			"description" 	=> __( 'button height, set in pixel', 'dual-btn' ),
			"value"			=>	"30",
			"suffix" 		=> 'px',
			"group" 		=> 'General',
		),
		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Button Width', 'dual-btn' ),
			"param_name" 	=> "width",
			"description" 	=> __( 'set button width, set in pixel', 'dual-btn' ),
			"value"			=>	"60",
			"suffix" 		=> 'px',
			"group" 		=> 'General',
		),
		array(
			"type" 			=> "vc_number",
			"heading" 		=> __( 'Text Font Size', 'dual-btn' ),
			"param_name" 	=> "size",
			"description" 	=> __( 'button text font size, set in pixel', 'dual-btn' ),
			"value"			=>	"20",
			"suffix" 		=> 'px',
			"group" 		=> 'General',
		),

		/* Button 1
		============================== */

		array(
			"type" 			=> "iconpicker",
			"heading" 		=> __( 'Choose Icon or leave blank', 'dual-btn' ),
			"param_name" 	=> "icon",
			"description" 	=> __( 'it will show with button text', 'dual-btn' ),
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Text', 'dual-btn' ),
			"param_name" 	=> "btn_text",
			"description" 	=> __( 'write button text', 'dual-btn' ),
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "vc_link",
			"heading" 		=> __( 'Text URL', 'dual-btn' ),
			"param_name" 	=> "url",
			"description" 	=> __( 'e.g: www.google.com', 'dual-btn' ),
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'dual-btn' ),
			"param_name" 	=> "txt_clr",
			"description" 	=> __( 'choose button text color', 'dual-btn' ),
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'background Color', 'dual-btn' ),
			"param_name" 	=> "bg_clr",
			"description" 	=> __( 'choose button background color', 'dual-btn' ),
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Hover Text Color', 'dual-btn' ),
			"param_name" 	=> "hvr_clr",
			"group" 		=> 'Button 1',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Color on Hover', 'dual-btn' ),
			"param_name" 	=> "hvr_bg",
			"group" 		=> 'Button 1',
		),

		/* Button 2
		============================== */

		array(
			"type" 			=> "iconpicker",
			"heading" 		=> __( 'Choose Icon or leave blank', 'dual-btn' ),
			"param_name" 	=> "icon2",
			"description" 	=> __( 'it will show with button text', 'dual-btn' ),
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Text', 'dual-btn' ),
			"param_name" 	=> "btn_text2",
			"description" 	=> __( 'write button text', 'dual-btn' ),
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "vc_link",
			"heading" 		=> __( 'Text URL', 'dual-btn' ),
			"param_name" 	=> "url2",
			"description" 	=> __( 'e.g: www.google.com', 'dual-btn' ),
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Open URL OnClick', 'dual-btn' ),
			"param_name" 	=> "target2",
			"group" 		=> 'Button 2',
			"value"			=>	array(
				"Same Widow"	=>	"none",
				"New Tab"	=>	"_blank",
			)
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'dual-btn' ),
			"param_name" 	=> "txt_clr2",
			"description" 	=> __( 'choose button text color', 'dual-btn' ),
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'background Color', 'dual-btn' ),
			"param_name" 	=> "bg_clr2",
			"description" 	=> __( 'choose button background color', 'dual-btn' ),
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Hover Text Color', 'dual-btn' ),
			"param_name" 	=> "hvr_clr2",
			"group" 		=> 'Button 2',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Color on Hover', 'dual-btn' ),
			"param_name" 	=> "hvr_bg2",
			"group" 		=> 'Button 2',
		),


		/* Divider
		============================== */
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Select Divider Options', 'dual-btn' ),
			"param_name" 	=> "divider",
			"group" 		=> 'Divider',
			"value"			=> array(
				"None"		=>	"none",
				"Text"		=>	"text",
				"Icon"		=>	"icon",
			)
		),
		array(
			"type" 			=> "iconpicker",
			"heading" 		=> __( 'Divider Icon', 'dual-btn' ),
			"param_name" 	=> "div_icon",
			"dependency" => array('element' => "divider", 'value' => 'icon'),
			"group" 		=> 'Divider',
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Text', 'dual-btn' ),
			"param_name" 	=> "divider_txt",
			"description" 	=> __( 'Enter your Divider text here.', 'dual-btn' ),
			"dependency" => array('element' => "divider", 'value' => 'text'),
			"group" 		=> 'Divider',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text/Icon Color', 'dual-btn' ),
			"param_name" 	=> "divider_clr",
			"description" 	=> __( 'Enter your Divider text here.', 'dual-btn' ),
			"group" 		=> 'Divider',
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text/Icon Background', 'dual-btn' ),
			"param_name" 	=> "divider_bg",
			"description" 	=> __( 'Enter your Divider text here.', 'dual-btn' ),
			"group" 		=> 'Divider',
		),
	),
) );

