jQuery(document).ready(function($) {

	if(jQuery('.equal-height .mason-item').length > 0){
		jQuery('.equal-height .mason-item').matchHeight({byRow: true}); 
	}
	$('a, i').hover(function() {
		$(this).css({
			'color': $(this).data('onhovercolor'),
			'background-color': $(this).data('onhoverbg')
		});
	}, function() {
		$(this).css({
			'color': $(this).data('onleavecolor'),
			'background-color': $(this).data('onleavebg')
		});		
	});
});

// CountDown timer
jQuery(document).ready(function($) {
	$(function () {
		$('.countdownapply').each(function(index, el) {
			var style = $(this).data('style');
			var year = $(this).data('year');
			var month = $(this).data('month');
			var date = $(this).data('date');
			var CountDown = new Date();
			CountDown = new Date(CountDown.getFullYear() + year, month - 1, date);
			$(this).countdown({until: CountDown, format: style});
		});
	});
});