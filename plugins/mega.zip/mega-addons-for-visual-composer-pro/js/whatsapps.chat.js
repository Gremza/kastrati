jQuery(document).ready(function($) {
    $(".uae-whatsapp-link-3, .uae_whatsapp_chat_5 .wa_popup_close_btn").click(function(event) {
        var sib = $(this).siblings();
        var statusBW = $(this).attr('data-active-status');
        if(statusBW == "false"){
            $(this).attr('data-active-status','true');
            $(this).find('.uae_whatsapp_icon').addClass('wa-popup-active');
            $(this).find('.uae_cross_icon').addClass('cross-popup-active');
        }else{
            $(this).attr('data-active-status','false');
            $(this).find('.uae_whatsapp_icon').removeClass('wa-popup-active');
            $(this).find('.uae_cross_icon').removeClass('cross-popup-active');
        }
    });

    $(".uae-whatsapp-link-3").click(function(){
        var sib = $(this).siblings();
        $(sib).toggleClass("open");
        return false;
    });
});