jQuery(document).on('ready', function() {
	jQuery( ".mySpriteSpin" ).each(function(index, el) {
		var captureMain = jQuery(this);
	    var animate 	= jQuery(this).data('animate');
	    var loop    	= jQuery(this).data('loop');
	    var reverse    	= jQuery(this).data('reverse');
	    var retainanimate   = jQuery(this).data('retainanimate');
	    var frame   = jQuery(this).data('frame');
	    var frametime   = jQuery(this).data('frametime');
	    var blur   		= jQuery(this).data('blur');
	    var ease   		= jQuery(this).data('ease');
	    var behavior   		= jQuery(this).data('behavior');
	    var images = jQuery(this).data("images");

		jQuery(this).siblings('a.js-fullscreen').click(function(e) {
		    e.preventDefault();
		    console.log("clicked");
		    jQuery(this).siblings('.mySpriteSpin').spritespin('api').requestFullscreen();
		});

		var res = images.split(",");

		var imgData=[];

		for (var i = 0; i < res.length; i++) {
			imgData.push(res[i]);
		};

		var testVal = ["360"];
		
		if(ease != "")
			testVal.push("ease");
		if(blur != "")
			testVal.push("blur");
		if(behavior != "")
			testVal.push(behavior);

		jQuery(this).spritespin({
		  source: imgData,

		 	//  width : 600,
			// height: 400,
			// sizeMode
			
			sense : -1,
			animate : animate,
			loop: loop,
			reverse: reverse,
			retainAnimate: retainanimate,
			frameWrap : true,
			frame : frame,
			frameStep : 1,
			frameTime : frametime,
			enableCanvas : true,
			responsive: true,
			progress: 'PreloadProgress',
			plugins: 
		      testVal
		    ,
		    blurCss: true,
		    blurFadeTime: 100,
		    onFrame: function(e, data) {
		      jQuery(this).siblings('.spritespin-slider').val(data.frame)
		    },
		    onInit: function(e, data) {
		      jQuery(this).siblings('.spritespin-slider')
		        .attr("min", 0)
		        .attr("max", data.source.length - 1)
		        .attr("value", 0)
		        .on("input", function(e) {
		          SpriteSpin.updateFrame(data, e.target.value);
		        })
		    }
		});
	});
});