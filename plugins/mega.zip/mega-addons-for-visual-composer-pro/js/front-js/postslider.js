jQuery(document).ready(function($) {
	if(jQuery('.equal-height .mason-item').length > 0){
		jQuery('.equal-height .mason-item').matchHeight({byRow: true});
	}
});