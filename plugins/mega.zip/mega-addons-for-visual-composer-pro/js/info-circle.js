jQuery(document).ready(function($) {

	//with jquery
	$('.pause').on('click', function(e) {
	  e.preventDefault();
	  isPaused = true;
	});

	$('.play').on('click', function(e) {
	  e.preventDefault();
	  isPaused = false;
	});



	$('.mega-info-circle').each(function() {
		var cTag = "data-circle-run";
		var dRun = $(d).attr(cTag);
		var ci=0;
		//var output = $('h1');
		//var isPaused = false;
		var time = 0;
		//var inner_section = $(this).find('.icon-wrapper').closest('.mega-info-circle').find('.mega-inner-section > div > div');
		//var content = $(this).find('.icon-wrapper').find('div').clone();
		//console.log(content);
		//$(inner_section).html(content).css({opacity: 0.0, visibility: "visible"}).animate({opacity: 1.0});
		//var = document.ge
		var d = $(this);
		var e = $(d).find(".icon-wrapper");
		var f = $(d).find("[data-order='"+0+"']");
	  	$(d).find(".icon-wrapper").removeClass("active-circle");
	  	$(f).addClass("active-circle");
  		var h = $(d).find(".mega-inner-section > div > div > div");
  		//$(f).find(".info-circle-detail").html();
  		var g = $(f).html();
  		$(h).html(g);

  		var aniHover = 3000;
		ci=1;
	    var t = setInterval(function() {
		  if($(d).attr(cTag) == "true") {
		  	if(ci<e.length){
		  		//var f = $(d).find("[data-order='"+ci+"']");
		  		//var h = $(d).find(".mega-inner-section > div > div > div");
		  		//$(f).find(".info-circle-detail").html();
		  		//var g = $(f).html();
		  		//$(h).html(g);
		  		//$(inner_section).html(content).css({opacity: 0.0, visibility: "visible"}).animate({opacity: 1.0});
		  		//$(h).css({opacity: 0.0, visibility: "visible"}).animate({opacity: 1.0});
		  		//$(h).html("test "+g);
		  		//$(h).html("");

		  		//console.log(g);
		  		//$(d).removeClass("active-circle");
		  		//$(d[ci]).addClass("active-circle");



		  		// console.log("Seconds: " + ci);
		  		
		  		time++;
		  	}else{
		  		//$(d).removeClass("active-circle");
		  		//$(d[ci]).addClass("active-circle");
		  		ci=0;
		  		time=0;
		  		// console.log("Seconds: " + ci);
		  	}

		  	var f = $(d).find("[data-order='"+ci+"']");
		  	$(d).find(".icon-wrapper").removeClass("active-circle");
		  	$(f).addClass("active-circle");
	  		var h = $(d).find(".mega-inner-section > div > div > div");
	  		//$(f).find(".info-circle-detail").html();
	  		var g = $(f).html();
	  		$(h).html(g);
		    
		    ci++;
		  
		  }

		}, aniHover);

	    
	    $(this).find('.icon-wrapper').mouseover(function() {
	    	$(this).parent().parent().attr(cTag,"false");
	    	var d = $(this);
	    	var e = (d).parent().find(".mega-inner-section  > div > div > div");
	    	$(e).html($(this).html());
	    	$(d).parent().parent().find(".icon-wrapper").removeClass("active-circle");
	    	$(d).addClass("active-circle");
	    	ci = $(d).attr("data-order");
	    	//$(d).html()
	    	
	    });

	    $(this).find('.icon-wrapper').mouseout(function() {
	    	var dRun = $(d).attr(cTag);
	    	if(dRun == "false"){
	    		$(this).parent().parent().attr(cTag,"true");
	    	}
	    });




/*
	    $(this).find('.icon-wrapper').on("mouseout",function() {
	    	if($(this).parent().attr("isRunning") == "true"){
	    		isPaused = true;	
	    	}
	    	isPaused = false;
	    });*/


		//alert(d.length);
		//var inner_section = $(this).closest('.mega-info-circle').find('.mega-inner-section > div > div');
		//var content = $(this).find('div').clone();



		/*
		$(this).hover(function() {
			setTimeout(function(){
				$(inner_section).html(content).css({opacity: 0.0, visibility: "visible"}).animate({opacity: 1.0});
			}, 400);
		}, function() {
			
		});*/

		//if (index % 5 == 0) {
		//	$(this).trigger('mouseenter');
		//}
	});



});