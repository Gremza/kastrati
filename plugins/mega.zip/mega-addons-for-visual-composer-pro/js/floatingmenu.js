jQuery(document).ready(function($) {	
	$(".maw_floatmenu_main_wrapper a[href^='#'], .maw_floatmenu_main_wrapper a[href^='.']").click(function(e) {
		e.preventDefault();
		var p = jQuery(this).parent().parent().parent().parent();
		var speed = jQuery(p).attr("data-scrollspeed");
		
		var topspace = jQuery(p).attr("data-topspace");
		var position = $($(this).attr("href")).offset().top;
		$("body, html").stop();
		$("body, html").animate({
			scrollTop: position-parseInt(topspace)
		} ,parseInt(speed) );
	});
});