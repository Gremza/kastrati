jQuery(document).ready(function(){
	jQuery( ".ihe-fancybox" ).each(function(index, el) {
		var effect  = jQuery(this).data('slide');
		var effect 		= '"' + effect + '"';
		// console.log(effect);
		jQuery('[data-fancybox="images"]').fancybox({
		    protect: true,
		    keyboard: true,
	  		infobar: false, // Should display counter at the top left corner
	  		toolbar: true,
		});
	});
});
